import json

INPUT_JSON = "pad_origin_correct.json"
OUTPUT_JSON = "pad_origin_final.json"
CONFIDENCE_THRESHOLD = 0.8

with open(INPUT_JSON, "r") as f:
    data = json.load(f)

print("📥 Loading data...")
print(f"Total samples: {len(data)}")

# Filter: confidence > 0.9 AND is_correct = True
filtered = [
    row for row in data
    if row.get("is_correct", False) == True
    and row.get("correctness_confidence", -1.0) >= CONFIDENCE_THRESHOLD
]

print(f"\n=== FILTERING RESULTS ===")
print(f"Confidence threshold: >= {CONFIDENCE_THRESHOLD}")
print(f"Requirement: is_correct = True")
print(f"\nSamples after filtering: {len(filtered)}")
print(f"Percentage kept: {len(filtered)/len(data)*100:.1f}%")
print(f"Samples removed: {len(data) - len(filtered)}")

# Save filtered data
with open(OUTPUT_JSON, "w") as f:
    json.dump(filtered, f, indent=2)

print(f"\n✅ Filtered data saved to: {OUTPUT_JSON}")
