import json

INPUT_JSON = "pad_compat1.json"
OUTPUT_JSON = "pad_compat_filtered1.json"

THRESHOLD = 0.8

with open(INPUT_JSON, "r") as f:
    data = json.load(f)

print("Total samples before:", len(data))

filtered = [
    row for row in data
    if row.get("reward_compatibility_confidence", -1.0) >= THRESHOLD
]

print(f"Samples after filtering (confidence >={THRESHOLD}):", len(filtered))
print(f"Percentage kept: {len(filtered)/len(data)*100:.1f}%")

with open(OUTPUT_JSON, "w") as f:
    json.dump(filtered, f, indent=2)

print("✅ Saved filtered file →", OUTPUT_JSON)
