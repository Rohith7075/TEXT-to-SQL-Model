import json
import os
import time
from openai import OpenAI
from tqdm import tqdm
from concurrent.futures import ThreadPoolExecutor, as_completed

# ===============================
# CONFIG
# ===============================

INPUT_JSON = "pad_new1.json"
OUTPUT_JSON = "pad_compat1.json"
MODEL = "gpt-5.2"

MAX_WORKERS = 50      # 🔥 increase slowly (8 → 16 → 32)
SLEEP_BETWEEN = 0.02    # safety

client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))

# ===============================
# PROMPTS
# ===============================


SQL_REWARD_COMPATIBILITY_INSTRUCTION = """You are a Compatibility Auditor for Text-to-SQL Reinforcement Learning.

## OBJECTIVE
Assign a "Structural Compatibility Confidence" (0.0-1.0) indicating how likely a logically correct SQL query will produce an **execution result that byte-matches or row-matches** the Ground Truth (GT). Low confidence indicates high risk of "correct but uncomparable" outputs (false negatives in RL reward calculation).

## CRITICAL FAILURE MODES (Detect These)

### 1. Column Substitution Risk [Weight: High]
- **Multiple IDs**: Schema contains semantically equivalent identifiers (e.g., `user.id`, `user.user_uuid`, `user.account_number`)
- **Implicit Select**: Question implies `SELECT *` or vague projection ("show user details") allowing varying column subsets
- **Aliasing Freedom**: GT uses aliases not mandated by the question (`SELECT name AS user_name` vs `SELECT name`)

### 2. Ordering Volatility [Weight: Critical]
- **Unordered Results**: GT returns multiple rows but lacks `ORDER BY`. Correct queries may return identical data in different sequences, breaking row-wise comparison metrics (e.g., exact match, token overlap).

### 3. Join Path Ambiguity [Weight: High]
- **Multiple FKs**: Tables connect via multiple valid foreign keys (e.g., `orders.user_id` vs `orders.buyer_id` both valid)
- **Implicit vs Explicit**: GT uses implicit joins (`WHERE a.id = b.id`) but model might use explicit `JOIN` syntax (logically equal, textually different)

### 4. Serialization Complexity [Weight: Medium]
- **Nested Structures**: GT uses BigQuery STRUCTs/ARRAYs, Postgres JSONB, or SQLite BLOBs that serialize inconsistently across engines
- **Date/Float Precision**: Unspecified date formats (ISO vs locale) or floating-point rounding differences

### 5. Aggregation Granularity [Weight: Medium]
- **Rounding Unspecified**: "Average price" could be `AVG(price)` or `ROUND(AVG(price), 2)`
- **NULL Handling**: Question doesn't specify `COALESCE` vs raw NULLs in results

## CONFIDENCE RUBRIC

- **0.95-1.0 (Deterministic Scalar)**: Single-value output (count, max, specific lookup by unique key). Only one correct result possible.
- **0.8-0.94 (Structurally Rigid)**: Explicit column list, single table or deterministic join path, includes `ORDER BY` if multi-row.
- **0.5-0.79 (Moderate Risk)**: Minor ambiguity (e.g., 2 possible ID columns but one is obviously primary), or lack of ordering on small result sets.
- **0.2-0.49 (High Friction)**: Multiple valid projections ("list products"), no ordering on large results, multiple join paths, or complex nested types.
- **0.0-0.19 (Uncomparable)**: Extreme ambiguity (e.g., "retrieve data" with 20+ columns, BigQuery arrays without UNNEST, implicit SELECT *).

## OUTPUT FORMAT
You must output ONLY valid JSON. No markdown blocks, no explanations outside JSON.
"""


# Removed - will build as dict instead to avoid JSON formatting issues

# ===============================
# OPENAI CALL
# ===============================

def call_openai(instruction, user_prompt):
    response = client.responses.create(
        model=MODEL,
        input=[
            {"role": "developer", "content": instruction},
            {"role": "user", "content": user_prompt}
        ]
    )
    return response.output_text


# ===============================
# COMPATIBILITY FUNCTION
# ===============================

def reward_compatibility(schema, question, sql_query):
    # Build prompt as dict to ensure valid JSON
    prompt_dict = {
        "evaluation_target": {
            "schema": schema,
            "question": question,
            "ground_truth_sql": sql_query
        },
        "analysis_requirements": [
            "Identify all semantically equivalent column sets (e.g., [id, uuid, record_id])",
            "Check for ORDER BY clause in GT if query returns multiple rows",
            "Flag any STRUCT/ARRAY/JSONB types in schema",
            "Determine if question specifies exact columns or allows variation"
        ],
        "response_schema": {
            "confidence": "float (0.0-1.0)",
            "risk_level": "CRITICAL|HIGH|MEDIUM|LOW|NONE",
            "primary_friction_points": [
                {
                    "category": "COLUMN_AMBIGUITY|ORDERING_VOLATILITY|JOIN_MULTIPLICITY|SERIALIZATION_RISK|AGGREGATION_FLEX",
                    "severity": "1-10",
                    "description": "Specific issue (e.g., 'Table users has both id and user_id; question asks for user identifier')",
                    "mitigation": "How to fix (e.g., 'Add explicit column: SELECT user_id specifically')"
                }
            ],
            "comparison_strategy": "ROW_WISE|SET_COMPARE|SCALAR|UNSAFE",
            "recommendation": "INCLUDE|FILTER|MODIFY_QUESTION"
        }
    }
    prompt = json.dumps(prompt_dict)

    try:
        output = call_openai(
            SQL_REWARD_COMPATIBILITY_INSTRUCTION,
            prompt
        )
        # Debug: print first 200 chars of output
        # print(f"API Output: {output[:200]}...")
        return json.loads(output)

    except json.JSONDecodeError as e:
        print(f"⚠️  JSON Parse Error: {e}")
        print(f"Output preview: {output[:500] if 'output' in locals() else 'No output'}")
        return {
            "confidence": -1.0,
            "risk_level": "UNKNOWN",
            "error": f"JSON parse error: {str(e)}"
        }
    except Exception as e:
        print(f"⚠️  API Error: {e}")
        return {
            "confidence": -1.0,
            "risk_level": "UNKNOWN",
            "error": str(e)
        }


# ===============================
# WORKER FUNCTION (ONE ROW)
# ===============================

def process_row(idx_row):
    idx, row = idx_row

    try:
        schema = row["extra_info"]["schema"]
        question = row["extra_info"]["question"]
        sql_query = row["reward_model"]["ground_truth"]

        compat = reward_compatibility(schema, question, sql_query)

        row["reward_compatibility"] = compat
        row["reward_compatibility_confidence"] = compat.get("confidence", -1.0)

    except Exception as e:
        print(f"❌ Row {idx} error: {e}")
        row["reward_compatibility"] = None
        row["reward_compatibility_confidence"] = -1.0
        row["error"] = str(e)

    time.sleep(SLEEP_BETWEEN)
    return idx, row


# ===============================
# MAIN
# ===============================

def main():
    print("📥 Loading input JSON...")
    with open(INPUT_JSON, "r") as f:
        data = json.load(f)


    results = [None] * len(data)

    print(f"🚀 Scoring with {MAX_WORKERS} threads...")

    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        futures = [
            executor.submit(process_row, (idx, row))
            for idx, row in enumerate(data)
        ]

        for future in tqdm(as_completed(futures), total=len(futures)):
            idx, row = future.result()
            results[idx] = row

    print("💾 Saving output JSON...")
    with open(OUTPUT_JSON, "w") as f:
        json.dump(results, f, indent=2)

    print("✅ DONE")
    print(f"Saved → {OUTPUT_JSON}")


if __name__ == "__main__":
    main()
