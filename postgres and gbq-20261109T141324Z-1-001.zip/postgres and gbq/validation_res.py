# Copyright 2024 Bytedance Ltd. and/or its affiliates
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import re
import os
import ast
import sqlite3
from google.cloud import bigquery
import threading
import traceback
import json
from datetime import date, datetime
from deepdiff import DeepDiff
from typing import Dict, List, Any, Optional, Union
from functools import wraps
import time
import logging
import sys

# Single shared log file for all workers (no terminal output)
_REWARD_LOG_LOCK = threading.Lock()
_REWARD_LOGGER = None

_SOLUTION_CLIP_CHARS = 300


BILLING_PROJECT_ID = os.getenv("BILLING_PROJECT_ID")
DATA_PROJECT_ID = os.getenv("DATA_PROJECT_ID")
DATASET_ID = os.getenv("DATASET_ID")

print(f"BILLING_PROJECT_ID: {BILLING_PROJECT_ID}")
print(f"DATA_PROJECT_ID: {DATA_PROJECT_ID}")
print(f"DATASET_ID: {DATASET_ID}")


def get_reward_logger():
    # Log system removed
    return None

# Add thread-local storage
_thread_local = threading.local()

def retry_on_bq_error(max_retries=3, initial_delay=1.0):
    """Retry decorator for BigQuery operations."""
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            # Logging removed
            for attempt in range(max_retries):
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    error_msg = str(e).lower()
                    # Retry on rate limit or connection errors
                    if any(keyword in error_msg for keyword in 
                           ['rate limit', 'quota', 'timeout', 'connection']):
                        if attempt < max_retries - 1:
                            delay = initial_delay * (2 ** attempt)  # Exponential backoff
                            time.sleep(delay)
                            continue
                    # Non-retryable error or max retries reached
                    raise
            return None
        return wrapper
    return decorator

def get_bigquery_client():
    """
    Get or create a process/thread-local BigQuery client.
    Each worker process gets its own client instance.
    """
    if not hasattr(_thread_local, 'bq_client'):
        _thread_local.bq_client = bigquery.Client(project=BILLING_PROJECT_ID)
    return _thread_local.bq_client

def execute_sql_with_data(
    schema: str,
    insert_statements: Union[str, List[str]],
    query: str,
    return_all_rows: bool = False
) -> Dict[str, Any]:
    """
    Execute a SQL query with given schema and data insertions.
    
    Args:
        schema: SQL schema definition (CREATE TABLE statements)
        insert_statements: Single INSERT statement string or list of INSERT statements
        query: SQL query to execute
        return_all_rows: If True, returns all rows; if False, returns only first row
    
    Returns:
        Dictionary containing:
            - 'success': Boolean indicating if query executed successfully
            - 'result': Query result as list of dictionaries with column names as keys
            - 'error': Error message if execution failed (None if successful)
            - 'column_names': List of column names from the query result
    """
    conn = None
    result_dict = {
        'success': False,
        'result': None,
        'error': None,
        'column_names': []
    }
    # logger removed
    try:
        # Connect to in-memory database
        conn = sqlite3.connect(":memory:")
        cursor = conn.cursor()

        # clean up the sql query by adding # SQLite compatibility fixes
        def fix_sql_compatibility(sql_text):
            if not sql_text:
                return sql_text
            
            sql_text = re.sub(r'\bBYTEA\b', 'BLOB', sql_text, flags=re.IGNORECASE)
            sql_text = re.sub(r'\bTIMESTAMP\b', 'DATETIME', sql_text, flags=re.IGNORECASE)
            sql_text = re.sub(r'\bSMALLINT\b', 'INTEGER', sql_text, flags=re.IGNORECASE)
            sql_text = re.sub(r'\bDOUBLE\s+PRECISION\b', 'REAL', sql_text, flags=re.IGNORECASE)
            sql_text = re.sub(r'\bSERIAL\b', 'INTEGER', sql_text, flags=re.IGNORECASE)
            return sql_text

        schema = fix_sql_compatibility(schema)
        insert_statements = fix_sql_compatibility(insert_statements)
        query = fix_sql_compatibility(query)
        
        # Execute schema
        cursor.executescript(schema)
        
        # Execute insert statements
        if isinstance(insert_statements, str):
            cursor.executescript(insert_statements)
        elif isinstance(insert_statements, list):
            for stmt in insert_statements:
                cursor.executescript(stmt)
        
        # Commit the inserts
        conn.commit()
        
        # Execute the query
        cursor.execute(query)
        
        # Get column names
        column_names = []
        if cursor.description:
            column_names = [desc[0] for desc in cursor.description]
            result_dict['column_names'] = column_names
        
        # Fetch results and convert to dictionaries
        if return_all_rows:
            rows = cursor.fetchall()
            # Convert list of tuples to list of dictionaries
            result_dict['result'] = [
                dict(zip(column_names, row)) for row in rows
            ]
        else:
            row = cursor.fetchone()
            # Convert single tuple to dictionary
            if row:
                result_dict['result'] = dict(zip(column_names, row))
            else:
                result_dict['result'] = None
        
        result_dict['success'] = True

    except Exception as e:
        result_dict['success'] = False
        result_dict['error'] = f"{type(e).__name__}: {str(e)}"
        result_dict['traceback'] = traceback.format_exc()

    finally:
        if conn:
            conn.close()

    return result_dict

@retry_on_bq_error(max_retries=3)
def execute_bq_with_data(query, project_id, dataset_id):
    """
    Execute BigQuery query. Replaces placeholder project/dataset with correct values.
    Note: Removed 'client' parameter - we get it internally now.
    """
    result_dict = {
        'success': False,
        'result': None,
        'error': None,
        'column_names': []
    }
    # logger removed
    try:
        # Get process-local client
        client = get_bigquery_client()
        # Simple replacement of project.dataset prefix with correct values
        updated_query = query.replace(
            f"`{project_id}.{dataset_id}.",
            f"`{DATA_PROJECT_ID}.{DATASET_ID}."
        )
        updated_query = updated_query.replace(
            f"{project_id}.{dataset_id}.",
            f"{DATA_PROJECT_ID}.{DATASET_ID}."
        )
        query_job = client.query(updated_query)
        query_results = query_job.result()
        
        result_rows = [dict(row) for row in query_results]
        
        if result_rows:
            result_dict['success'] = True
            result_dict['result'] = result_rows
            result_dict['column_names'] = list(result_rows[0].keys())
        else:
            result_dict['success'] = True
            result_dict['result'] = []
            result_dict['column_names'] = []
        
        return result_dict

    except Exception as e:
        result_dict['error'] = str(e)
        return result_dict



def simplify_query_result(result: Union[tuple, List[tuple], None]) -> str:
    """
    Convert SQL query result to a simple string format.
    Handles all edge cases.
    
    Args:
        result: Query result (tuple for single row, list of tuples for multiple rows, or None)
    
    Returns:
        String representation of the result
    """
    # Handle None result (no rows returned)
    if result is None:
        return "No results"
    
    # Handle empty result set
    if isinstance(result, list) and len(result) == 0:
        return "No results"
    
    # Handle single row result (tuple)
    if isinstance(result, tuple):
        if len(result) == 0:
            return "No results"
        elif len(result) == 1:
            # Single value in single row
            return format_value(result[0])
        else:
            # Multiple values in single row
            return ", ".join(format_value(v) for v in result)
    
    # Handle multiple rows result (list of tuples)
    if isinstance(result, list):
        if len(result) == 1:
            # Only one row returned
            row = result[0]
            if len(row) == 1:
                # Single value in single row
                return format_value(row[0])
            else:
                # Multiple values in single row
                return ", ".join(format_value(v) for v in row)
        else:
            # Multiple rows returned
            formatted_rows = []
            for row in result:
                if len(row) == 1:
                    formatted_rows.append(format_value(row[0]))
                else:
                    formatted_rows.append("(" + ", ".join(format_value(v) for v in row) + ")")
            return "; ".join(formatted_rows)
    
    # Fallback for unexpected result types
    return str(result)


def format_value(value: Any) -> str:
    """
    Format a single value to string, handling None and various data types.
    
    Args:
        value: Any value to format
    
    Returns:
        Formatted string representation
    """
    if value is None:
        return "NULL"
    elif isinstance(value, float):
        # Format floats to avoid unnecessary decimals
        if value.is_integer():
            return str(int(value))
        else:
            return str(value)
    elif isinstance(value, str):
        return value
    else:
        return str(value)


def extract_simple_result(result_dict: Dict[str, Any]) -> str:
    """
    Extract a simple string result from the execute_sql_with_data result dictionary.
    This function is kept for backwards compatibility.
    
    Args:
        result_dict: Dictionary returned by execute_sql_with_data
    
    Returns:
        String representation of the result, handling all edge cases
    """
    # Check if query failed
    if not result_dict['success']:
        return f"Error: {result_dict['error']}"
    
    # Use simplify_query_result to handle the result
    return simplify_query_result(result_dict['result'])


def execute_sql_simple(
    schema: str,
    insert_statements: Union[str, List[str]],
    query: str,
    return_all_rows: bool = False
) -> str:
    """
    Execute SQL query and return only the simple string result.
    This function is kept for backwards compatibility.
    
    Args:
        schema: SQL schema definition (CREATE TABLE statements)
        insert_statements: Single INSERT statement string or list of INSERT statements
        query: SQL query to execute
        return_all_rows: If True, returns all rows; if False, returns only first row
    
    Returns:
        Simple string representation of the query result
    """
    result_dict = execute_sql_with_data(schema, insert_statements, query, return_all_rows, simplify_result=True)
    if result_dict['success']:
        return result_dict['result']
    else:
        return f"Error: {result_dict['error']}"


def extract_solution(solution_str):
    if "```sql" in solution_str:
        solution_str = solution_str.split("</think>")[-1]
        parts = solution_str.split("```sql")
        if len(parts) > 1:
            final_answer = parts[-1].split("```")[0].strip()
            return final_answer


def normalize_result(result):
    """Normalize query results for comparison."""
    if not result:
        return []
    
    if isinstance(result, list):
        if all(isinstance(row, dict) for row in result):
            return sorted([
                {k: (round(v, 6) if isinstance(v, float) else v) for k, v in row.items()}
                for row in result
            ], key=lambda x: str(sorted(x.items())))
        else:
            return sorted([
                tuple(round(v, 6) if isinstance(v, float) else v for v in row)
                for row in result
            ])
    
    return result

def normalize_values(data):
    """Normalize values for comparison."""
    if not data:
        return []
    
    normalized = []
    for row in data:
        if isinstance(row, dict):
            normalized_row = {
                k: (round(v, 6) if isinstance(v, float) else v) 
                for k, v in row.items()
            }
            normalized.append(normalized_row)
        else:
            normalized.append(tuple(round(v, 6) if isinstance(v, float) else v for v in row))
    
    return normalized


def get_column_values_ordered(data, col_name):
    """
    Get ordered list of values for a column to create a unique signature.
    Maintains order to distinguish between columns with same value sets.
    """
    return tuple(str(row.get(col_name, '')) for row in data)


def calculate_column_similarity(values1, values2):
    """
    Calculate how similar two columns are (0 to 1).
    1.0 means perfect match.
    """
    if len(values1) != len(values2):
        return 0.0
    
    matches = sum(1 for v1, v2 in zip(values1, values2) if v1 == v2)
    return matches / len(values1) if len(values1) > 0 else 0.0


def find_column_mapping(json1, json2):
    """
    Automatically find best column mapping using Hungarian algorithm approach.
    
    Args:
        json1: Ground truth JSON (list of dicts)
        json2: Model output JSON (list of dicts)
    
    Returns:
        dict: Mapping from json1 columns to json2 columns
    """
    if not json1 or not json2:
        return {}
    
    cols1 = list(json1[0].keys()) if json1 else []
    cols2 = list(json2[0].keys()) if json2 else []
    
    # Calculate similarity matrix
    similarity_matrix = {}
    for col1 in cols1:
        values1 = get_column_values_ordered(json1, col1)
        similarity_matrix[col1] = {}
        for col2 in cols2:
            values2 = get_column_values_ordered(json2, col2)
            similarity_matrix[col1][col2] = calculate_column_similarity(values1, values2)
    
    # Greedy matching: match highest similarity first
    mapping = {}
    used_cols2 = set()
    
    # Sort all possible pairs by similarity (highest first)
    all_pairs = []
    for col1 in cols1:
        for col2 in cols2:
            all_pairs.append((similarity_matrix[col1][col2], col1, col2))
    
    all_pairs.sort(reverse=True)
    
    # Assign matches greedily
    for similarity, col1, col2 in all_pairs:
        if col1 not in mapping and col2 not in used_cols2:
            if similarity > 0.99:  # Only match if almost perfect
                mapping[col1] = col2
                used_cols2.add(col2)
    
    return mapping


def align_json_structure(json1, json2, mapping):
    """
    Align json2 structure to match json1 using the provided mapping.
    """
    aligned = []
    for row in json2:
        aligned_row = {}
        for col1, col2 in mapping.items():
            if col2 in row:
                aligned_row[col1] = row[col2]
        aligned.append(aligned_row)
    
    return aligned


def sort_data(data):
    """Sort list of dictionaries for comparison."""
    if not data:
        return []
    
    return sorted(data, key=lambda x: str(sorted(x.items())))


def compare_json_smart(ground_truth, model_output, similarity_threshold=0.99):
    """
    Compare ground truth with model output automatically finding column mapping.
    
    Args:
        ground_truth: Ground truth JSON (list of dicts)
        model_output: Model output JSON (list of dicts)
        similarity_threshold: Minimum similarity to consider columns matched (0-1)
    
    Returns:
        tuple: (bool: are_equal, dict: column_mapping, str: details)
    """
    if not ground_truth or not model_output:
        return False, {}, "Empty input"
    
    # Check if same number of rows
    if len(ground_truth) != len(model_output):
        return False, {}, f"Row count mismatch: {len(ground_truth)} vs {len(model_output)}"
    
    # Find column mapping automatically
    mapping = find_column_mapping(ground_truth, model_output)
    
    # Check if all columns were mapped
    gt_cols = set(ground_truth[0].keys()) if ground_truth else set()
    mapped_cols = set(mapping.keys())
    
    if gt_cols != mapped_cols:
        missing = gt_cols - mapped_cols
        return False, mapping, f"Could not map columns: {missing}"
    
    # Align model output to ground truth structure
    aligned_output = align_json_structure(ground_truth, model_output, mapping)
    
    # Normalize values
    normalized_gt = normalize_values(ground_truth)
    normalized_output = normalize_values(aligned_output)
    
    # Sort for comparison
    sorted_gt = sort_data(normalized_gt)
    sorted_output = sort_data(normalized_output)
    
    # Compare
    are_equal = sorted_gt == sorted_output
    
    if not are_equal:
        # Find differences for debugging
        details = "Data mismatch found"
    else:
        details = "Match successful"
    
    return are_equal, mapping, details


def compare_json_simple(ground_truth, model_output):
    """
    Simplified version that just returns True/False.
    """
    result, _, _ = compare_json_smart(ground_truth, model_output)
    return result

def normalize_ignore_keys(data):
    """
    Convert data to a sorted list of all values, ignoring keys and row structure.
    Treats the data as a multiset (bag) of values.
    """
    if not data:
        return []
    
    all_values = []
    
    if isinstance(data, list):
        for row in data:
            if isinstance(row, dict):
                # Extract values from each row and add to flat list
                for value in row.values():
                    # Normalize the value
                    if isinstance(value, float):
                        all_values.append(round(value, 6))
                    elif isinstance(value, str):
                        # Case-insensitive string comparison
                        all_values.append(value.lower())
                    else:
                        all_values.append(value)
    
    # Sort all values together
    return sorted(all_values, key=lambda x: (str(type(x).__name__), str(x)))

def compute_score(aditonal_info, solution_str, ground_truth, method="strict", 
                  format_score=0.0, score=1.0, syntax_score=0.1):
    """The scoring function for SQL queries with GRPO training."""
    # logger removed
    db_id = aditonal_info.get("db_id", "?")
    answer = extract_solution(solution_str=solution_str)
    schema = aditonal_info["schema"]
    insert_statements = aditonal_info["insert_statements"]
    execution_result = aditonal_info["execution_result"]
    if isinstance(execution_result, str):
        try:
            execution_result = json.loads(execution_result)
        except json.JSONDecodeError:
            # Try parsing as Python literal
            execution_result = ast.literal_eval(execution_result)
    query = answer
    sql_type = aditonal_info.get("SQL_Type", "gbq")

    if answer is None:
        return format_score

    try:
        if sql_type == "gbq":
            project_id = aditonal_info.get('project_id', DATA_PROJECT_ID)
            dataset_id = aditonal_info.get('dataset_id', DATASET_ID)
            result = execute_bq_with_data(
                query=query,
                project_id=project_id,
                dataset_id=dataset_id
            )
        elif sql_type == "postgres":
            result = execute_sql_with_data(
                schema,
                insert_statements,
                query,
                return_all_rows=True
            )
        else:
            raise ValueError(f"Invalid SQL type: {sql_type}")
    except Exception as e:
        return format_score, f"Execution failed: {str(e)}"

    value = result.get('result')
    value = normalize_result(value)
    execution_result = normalize_result(execution_result)

    if result["success"]:
        is_correct = (
            str(value) == str(execution_result)
            or compare_json_simple(value, execution_result)
            or normalize_ignore_keys(value) == normalize_ignore_keys(execution_result)
        )
        if is_correct:
            return score, value
        else:
            return syntax_score, value
    else:
        error_msg = result.get('error', 'Unknown error')
        return format_score, error_msg