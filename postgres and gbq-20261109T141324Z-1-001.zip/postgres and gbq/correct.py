import json
import os
import time
from openai import OpenAI
from tqdm import tqdm
from concurrent.futures import ThreadPoolExecutor, as_completed

# ===============================
# CONFIG
# ===============================

INPUT_JSON = "pad_origin.json"
OUTPUT_JSON = "pad_origin_correct.json"
MODEL = "gpt-5.2"

MAX_WORKERS = 60
SLEEP_BETWEEN = 0.02

client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))

# ===============================
# PROMPTS
# ===============================

SQL_CORRECTNESS_INSTRUCTION = """You are an expert SQL Validator specializing in PostgreSQL and Google BigQuery dialects.

# Your Mission
Determine if a SQL query correctly answers the given business question based on the provided schema.

# Input Components
1. **Schema**: Table structures with column names and data types and its description
2. **Business Question**: What the user wants to know from the data
3. **SQL Query**: The query to validate (Ground Truth Reference Answer)
4. **Additional Context**: Fiscal period details including timeline information, date ranges, and time period mappings (if provided)

# IMPORTANT: Ground Truth Leniency
This SQL is a REFERENCE ANSWER. Be lenient and practical:

## DO NOT mark as WRONG for:
- **Hard-coded dates/weeks**: If the query uses specific date ranges (e.g., 2026-02-01 to 2026-02-28) that match the fiscal context provided, this is ACCEPTABLE even if the question says "year to date" or "last week"
- **Aggregation choices**: If question asks for "contribution" or "share", but query returns absolute values that could be used to calculate share, mark as CORRECT (the share calculation may happen in presentation layer)
- **Column grain choices**: Choosing l4_name vs l5_name, store_name vs store_code, etc. are reasonable when multiple options exist
- **Missing ORDER BY**: Unless question explicitly requires ordering (e.g., "top 5"), missing ORDER BY is acceptable

## ONLY mark as WRONG for:
- **Schema Violations**: References tables/columns that don't exist in the provided schema
- **Syntax Errors**: Invalid SQL that won't execute
- **Dialect Errors**: Uses PostgreSQL syntax in BigQuery or vice versa that would cause execution failure
- **Blatant Semantic Mismatch**: Query answers a completely different question (e.g., question asks for sales, query returns inventory)
- **Wrong Table**: Uses sales table when question clearly asks about inventory data

# Validation Approach
1. Check if SQL references valid schema elements
2. Check if SQL is syntactically correct for BigQuery
3. Check if SQL broadly answers the business question intent
4. If uncertain, default to **is_correct = true** with lower confidence

# Output Requirements
Return ONLY valid JSON. No markdown blocks, no explanations outside JSON.

Format:
{
  "is_correct": boolean,
  "confidence": number 0.0-1.0,
  "issues": [{"type": "...", "severity": "...", "message": "..."}],
  "explanation": "brief explanation",
  "reasoning": "step-by-step analysis"
}
"""

# ===============================
# OPENAI CALL
# ===============================

def call_openai(instruction, user_prompt):
    response = client.responses.create(
        model=MODEL,
        input=[
            {"role": "developer", "content": instruction},
            {"role": "user", "content": user_prompt}
        ]
    )
    return response.output_text


# ===============================
# CORRECTNESS FUNCTION
# ===============================

def sql_correctness(schema, question, sql_query, additional_context=None):
    # Build prompt as dict to ensure valid JSON
    prompt_dict = {
        "schema": schema,
        "question": question,
        "query": sql_query,
        "required_output": {
            "is_correct": "boolean - true if query correctly answers the question",
            "confidence": "number 0.0-1.0 - your confidence in the correctness assessment (REQUIRED)",
            "issues": "array of issues found (can be empty if correct)",
            "explanation": "string - why correct or wrong",
            "reasoning": "string - step-by-step analysis"
        },
        "instruction": "Validate if this query correctly answers the question. You MUST include the 'confidence' field as a number between 0.0 and 1.0. Return ONLY valid JSON."
    }
    
    if additional_context:
        prompt_dict["additional_context"] = additional_context

    try:
        output = call_openai(
            SQL_CORRECTNESS_INSTRUCTION,
            json.dumps(prompt_dict)
        )
        result = json.loads(output)
        
        # If confidence is missing or 0, calculate it based on is_correct
        if "confidence" not in result or result.get("confidence", 0) == 0:
            #print("⚠️  API did not provide confidence - calculating fallback")
            # If marked as correct and no critical issues, high confidence
            if result.get("is_correct", False):
                issues = result.get("issues", [])
                critical_issues = [i for i in issues if i.get("severity") == "critical"]
                if len(critical_issues) == 0:
                    result["confidence"] = 0.95
                    #print(f"   → Set confidence to 0.95 (correct, no critical issues)")
                else:
                    result["confidence"] = 0.6
                    #print(f"   → Set confidence to 0.6 (correct, but has {len(critical_issues)} critical issues)")
            else:
                # If marked as incorrect, medium-high confidence
                result["confidence"] = 0.85
                #print(f"   → Set confidence to 0.85 (incorrect query)")
    
        return result

    except json.JSONDecodeError as e:
        return {
            "is_correct": False,
            "confidence": 0.0,
            "issues": [
                {
                    "severity": "critical",
                    "category": "system",
                    "description": f"JSON parse error: {str(e)}"
                }
            ],
            "fixed_query": None
        }
    except Exception as e:
        return {
            "is_correct": False,
            "confidence": 0.0,
            "issues": [
                {
                    "severity": "critical",
                    "category": "system",
                    "description": str(e)
                }
            ],
            "fixed_query": None
        }


# ===============================
# WORKER FUNCTION
# ===============================

def process_row(idx_row):
    idx, row = idx_row

    try:
        schema = row["extra_info"]["schema"]
        question = row["extra_info"]["question"]
        sql_query = row["reward_model"]["ground_truth"]
        additional_context = row["extra_info"].get("additional_context", None)

        correctness = sql_correctness(schema, question, sql_query, additional_context)

        row["sql_correctness"] = correctness
        row["is_correct"] = correctness.get("is_correct", False)
        row["correctness_confidence"] = correctness.get("confidence", 0.0)

    except Exception as e:
        row["sql_correctness"] = None
        row["is_correct"] = False
        row["correctness_confidence"] = 0.0
        row["error"] = str(e)

    time.sleep(SLEEP_BETWEEN)
    return idx, row


# ===============================
# MAIN
# ===============================

def main():
    print("📥 Loading input JSON...")
    with open(INPUT_JSON, "r") as f:
        data = json.load(f)

    results = [None] * len(data)

    print(f"🚀 Running correctness validation with {MAX_WORKERS} threads...")

    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        futures = [
            executor.submit(process_row, (idx, row))
            for idx, row in enumerate(data)
        ]

        for future in tqdm(as_completed(futures), total=len(futures)):
            idx, row = future.result()
            results[idx] = row

    print("💾 Saving output JSON...")
    with open(OUTPUT_JSON, "w") as f:
        json.dump(results, f, indent=2)

    print("✅ DONE")
    print(f"Saved → {OUTPUT_JSON}")


if __name__ == "__main__":
    main()