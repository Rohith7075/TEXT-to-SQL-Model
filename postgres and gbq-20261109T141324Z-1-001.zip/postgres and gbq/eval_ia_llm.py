import requests
import json
import re
import pandas as pd
import time
from validation_res import compute_score
from tqdm import tqdm

from openai import OpenAI
client = OpenAI(api_key="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")

data = pd.read_parquet("data/training_data_v0/eval_data_v0_100.parquet")

url = "http://10.61.0.194:30000/v1/chat/completions"

headers = {
    "Content-Type": "application/json"
}

# prompt = [
#       {
#         "content": "Given the following database schema with project_id as your_project and dataset_id as your_dataset:\n\nCREATE TABLE `your_project.your_dataset.census_bureau_acs_blockgroup_2010_5yr` (\n    geo_id STRING,\n    nonfamily_households FLOAT64,\n    family_households FLOAT64,\n    median_year_structure_built FLOAT64,\n    rent_burden_not_computed FLOAT64,\n    rent_over_50_percent FLOAT64,\n    rent_40_to_50_percent FLOAT64,\n    rent_35_to_40_percent FLOAT64,\n    rent_30_to_35_percent FLOAT64,\n    rent_25_to_30_percent FLOAT64,\n    rent_20_to_25_percent FLOAT64,\n    rent_15_to_20_percent FLOAT64,\n    rent_10_to_15_percent FLOAT64,\n    rent_under_10_percent FLOAT64,\n    total_pop FLOAT64,\n    male_pop FLOAT64,\n    female_pop FLOAT64,\n    median_age FLOAT64,\n    white_pop FLOAT64,\n    black_pop FLOAT64,\n    asian_pop FLOAT64,\n    hispanic_pop FLOAT64,\n    amerindian_pop FLOAT64,\n    other_race_pop FLOAT64,\n    two_or_more_races_pop FLOAT64,\n    not_hispanic_pop FLOAT64,\n    commuters_by_public_transportation FLOAT64,\n    households FLOAT64,\n    median_income FLOAT64,\n    income_per_capita FLOAT64,\n    housing_units FLOAT64,\n    vacant_housing_units FLOAT64,\n    vacant_housing_units_for_rent FLOAT64,\n    vacant_housing_units_for_sale FLOAT64,\n    median_rent FLOAT64,\n    percent_income_spent_on_rent FLOAT64,\n    owner_occupied_housing_units FLOAT64,\n    million_dollar_housing_units FLOAT64,\n    mortgaged_housing_units FLOAT64,\n    families_with_young_children FLOAT64,\n    two_parent_families_with_young_children FLOAT64,\n    two_parents_in_labor_force_families_with_young_children FLOAT64,\n    two_parents_father_in_labor_force_families_with_young_children FLOAT64,\n    two_parents_mother_in_labor_force_families_with_young_children FLOAT64,\n    two_parents_not_in_labor_force_families_with_young_children FLOAT64,\n    one_parent_families_with_young_children FLOAT64,\n    father_one_parent_families_with_young_children FLOAT64,\n    father_in_labor_force_one_parent_families_with_young_children FLOAT64,\n    commute_10_14_mins FLOAT64,\n    commute_15_19_mins FLOAT64,\n    commute_20_24_mins FLOAT64,\n    commute_25_29_mins FLOAT64,\n    commute_30_34_mins FLOAT64,\n    commute_45_59_mins FLOAT64,\n    aggregate_travel_time_to_work FLOAT64,\n    income_less_10000 FLOAT64,\n    income_10000_14999 FLOAT64,\n    income_15000_19999 FLOAT64,\n    income_20000_24999 FLOAT64,\n    income_25000_29999 FLOAT64,\n    income_30000_34999 FLOAT64,\n    income_35000_39999 FLOAT64,\n    income_40000_44999 FLOAT64,\n    income_45000_49999 FLOAT64,\n    income_50000_59999 FLOAT64,\n    income_60000_74999 FLOAT64,\n    income_75000_99999 FLOAT64,\n    income_100000_124999 FLOAT64,\n    income_125000_149999 FLOAT64,\n    income_150000_199999 FLOAT64,\n    income_200000_or_more FLOAT64,\n    renter_occupied_housing_units_paying_cash_median_gross_rent FLOAT64,\n    owner_occupied_housing_units_lower_value_quartile FLOAT64,\n    owner_occupied_housing_units_median_value FLOAT64,\n    owner_occupied_housing_units_upper_value_quartile FLOAT64,\n    married_households FLOAT64,\n    occupied_housing_units FLOAT64,\n    housing_units_renter_occupied FLOAT64,\n    dwellings_1_units_detached FLOAT64,\n    dwellings_1_units_attached FLOAT64,\n    dwellings_2_units FLOAT64,\n    dwellings_3_to_4_units FLOAT64,\n    dwellings_5_to_9_units FLOAT64,\n    dwellings_10_to_19_units FLOAT64,\n    dwellings_20_to_49_units FLOAT64,\n    dwellings_50_or_more_units FLOAT64,\n    mobile_homes FLOAT64,\n    housing_built_2005_or_later FLOAT64,\n    housing_built_2000_to_2004 FLOAT64,\n    housing_built_1939_or_earlier FLOAT64,\n    male_under_5 FLOAT64,\n    male_5_to_9 FLOAT64,\n    male_10_to_14 FLOAT64,\n    male_15_to_17 FLOAT64,\n    male_18_to_19 FLOAT64,\n    male_20 FLOAT64,\n    male_21 FLOAT64,\n    male_22_to_24 FLOAT64,\n    male_25_to_29 FLOAT64,\n    male_30_to_34 FLOAT64,\n    male_35_to_39 FLOAT64,\n    male_40_to_44 FLOAT64,\n    male_45_to_49 FLOAT64,\n    male_50_to_54 FLOAT64,\n    male_55_to_59 FLOAT64,\n    male_60_61 FLOAT64,\n    male_62_64 FLOAT64,\n    male_65_to_66 FLOAT64,\n    male_67_to_69 FLOAT64,\n    male_70_to_74 FLOAT64,\n    male_75_to_79 FLOAT64,\n    male_80_to_84 FLOAT64,\n    male_85_and_over FLOAT64,\n    female_under_5 FLOAT64,\n    female_5_to_9 FLOAT64,\n    female_10_to_14 FLOAT64,\n    female_15_to_17 FLOAT64,\n    female_18_to_19 FLOAT64,\n    female_20 FLOAT64,\n    female_21 FLOAT64,\n    female_22_to_24 FLOAT64,\n    female_25_to_29 FLOAT64,\n    female_30_to_34 FLOAT64,\n    female_35_to_39 FLOAT64,\n    female_40_to_44 FLOAT64,\n    female_45_to_49 FLOAT64,\n    female_50_to_54 FLOAT64,\n    female_55_to_59 FLOAT64,\n    female_60_to_61 FLOAT64,\n    female_62_to_64 FLOAT64,\n    female_65_to_66 FLOAT64,\n    female_67_to_69 FLOAT64,\n    female_70_to_74 FLOAT64,\n    female_75_to_79 FLOAT64,\n    female_80_to_84 FLOAT64,\n    female_85_and_over FLOAT64,\n    white_including_hispanic FLOAT64,\n    black_including_hispanic FLOAT64,\n    amerindian_including_hispanic FLOAT64,\n    asian_including_hispanic FLOAT64,\n    commute_5_9_mins FLOAT64,\n    commute_35_39_mins FLOAT64,\n    commute_40_44_mins FLOAT64,\n    commute_60_89_mins FLOAT64,\n    commute_90_more_mins FLOAT64,\n    households_retirement_income FLOAT64,\n    do_date STRING,\n    armed_forces FLOAT64,\n    civilian_labor_force FLOAT64,\n    employed_pop FLOAT64,\n    unemployed_pop FLOAT64,\n    not_in_labor_force FLOAT64,\n    pop_16_over FLOAT64,\n    pop_in_labor_force FLOAT64,\n    associates_degree FLOAT64,\n    bachelors_degree FLOAT64,\n    high_school_diploma FLOAT64,\n    less_one_year_college FLOAT64,\n    masters_degree FLOAT64,\n    one_year_more_college FLOAT64,\n    pop_25_years_over FLOAT64,\n    commute_35_44_mins FLOAT64,\n    commute_60_more_mins FLOAT64,\n    commute_less_10_mins FLOAT64,\n    commuters_16_over FLOAT64\n)\n\nQuestion: Which block groups look most rent-stressed, based on the share of households spending 40%+ of income on rent, and how do they rank (using geo_id as the tie-breaker)?\n\nGenerate the SQL query to answer this question.",
#         "role": "user"
#       }
#     ]
def run_query_and_print_results(prompt):
    payload = {
        "model": "default",
        "messages": prompt,
        "max_tokens": 4098
    }

    response = requests.post(url, headers=headers, json=payload)
    data = response.json()

    raw_output = data["choices"][0]["message"]["content"]

    # -----------------------------
    # Extract sections using regex
    # -----------------------------

    analysis_match = re.search(
        r"<\|channel\|>analysis<\|message\|>(.*?)<\|end\|>",
        raw_output,
        re.DOTALL
    )

    final_match = re.search(
        r"<\|start\|>assistant<\|channel\|>final<\|message\|>(.*)",
        raw_output,
        re.DOTALL
    )

    analysis_text = analysis_match.group(1).strip() if analysis_match else "No analysis found."
    final_text = final_match.group(1).strip() if final_match else "No final answer found."

    # -----------------------------
    # Pretty structured printing
    # -----------------------------

    print("\n" + "=" * 80)
    print("🧠 REASONING (ANALYSIS)")
    print("=" * 80)
    print(analysis_text)

    print("\n" + "=" * 80)
    print("✅ FINAL ANSWER")
    print("=" * 80)
    print(final_text)
    print("=" * 80 + "\n")
    return final_text


def _normalize_content(content):
    """Ensure content is in Responses API format: list of {type, text} blocks."""
    if isinstance(content, str):
        return [{"type": "input_text", "text": content}]
    if isinstance(content, list):
        return [
            item if isinstance(item, dict) and "type" in item else {"type": "input_text", "text": str(item)}
            for item in content
        ]
    return [{"type": "input_text", "text": str(content)}]


def run_query_openai(prompt, model="gpt-5.2", reasoning="high"):
    if isinstance(prompt, str):
        input_messages = [{"role": "user", "content": _normalize_content(prompt)}]
    elif isinstance(prompt, list) and prompt and isinstance(prompt[0], dict):
        input_messages = [
            {"role": msg.get("role", "user"), "content": _normalize_content(msg.get("content", ""))}
            for msg in prompt
        ]
    else:
        input_messages = [{"role": "user", "content": _normalize_content(prompt)}]

    response = client.responses.create(
        model=model,
        reasoning={"effort": reasoning},
        input=input_messages,
    )

    return response.output_text

NO_TEST = len(data)
from concurrent.futures import ThreadPoolExecutor, as_completed
import threading

results = []
results_lock = threading.Lock()

def process_single_query(idx):
    """Process a single query and return the result."""
    prompt = data['prompt'][idx].tolist()
    start_time = time.time()
    # final_text = run_query_and_print_results(prompt, url, headers)
    final_text = run_query_openai(prompt)
    end_time = time.time()
    # print(f"Time taken to generate query {idx}: {end_time - start_time} seconds")
    aditonal_info = data['extra_info'][idx]
    ground_truth = data['reward_model'][0]['ground_truth']
    score = compute_score(aditonal_info, final_text, ground_truth)
    # print("=" * 80)
    # print(f"Query {idx} - Score: {score}")
    # print("=" * 80 + "\n")
    
    # Return result dictionary
    return {
        'prompt': prompt,
        'ground_truth': ground_truth,
        'final_text': final_text,
        'score': score,
        'time_taken': end_time - start_time
    }

# Use ThreadPoolExecutor for parallel processing
max_workers = min(10, NO_TEST)  # Adjust max_workers as needed
with ThreadPoolExecutor(max_workers=max_workers) as executor:
    # Submit all tasks
    future_to_idx = {executor.submit(process_single_query, idx): idx for idx in range(NO_TEST)}
    
    # Process completed tasks with progress bar
    for future in tqdm(as_completed(future_to_idx), total=NO_TEST, desc="Processing queries"):
        idx = future_to_idx[future]
        try:
            result = future.result()
            with results_lock:
                results.append(result)
        except Exception as exc:
            print(f"Query {idx} generated an exception: {exc}")

# Calculate and print score statistics
total_tests = len(results)
successful_tests = sum(1 for r in results if r['score'][0] == 1.0)
percentage = (successful_tests / total_tests * 100) if total_tests > 0 else 0

print("\n" + "=" * 80)
print("📊 EVALUATION SUMMARY")
print("=" * 80)
print(f"Total tests: {total_tests}")
print(f"Successful tests: {successful_tests}")
print(f"Success rate: {percentage:.2f}%")
print("=" * 80 + "\n")


# Save results to file
import json
output_file = 'eval_ia_llm_gpt52_high.json'
with open(output_file, 'w') as f:
    json.dump(results, f, indent=2)
print(f"\nResults saved to {output_file}")