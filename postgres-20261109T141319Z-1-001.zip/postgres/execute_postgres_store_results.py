import json
import sys
import re
from pathlib import Path
from tqdm import tqdm
import time
import multiprocessing
from datetime import datetime, date, time as dt_time, timedelta
from decimal import Decimal
import signal

try:
    import duckdb
except ImportError:
    import subprocess
    subprocess.check_call([sys.executable, "-m", "pip", "install", "duckdb"])
    import duckdb

# ============================================================================
# CONFIGURATION
# ============================================================================

INPUT_FILE = "/Users/pratheekreddy/Downloads/Postgres_data_code/Data_creation/pacsun_dev_insert.json"
OUTPUT_DIR = None  # None = same directory as input file
QUERY_TIMEOUT = 5  # Maximum seconds per query (reduced to fail fast)
CHECKPOINT_INTERVAL = 1000  # Save progress every N entries
NUM_WORKERS = 4  # Number of parallel workers (reduced to save memory)
BATCH_SIZE = 100  # Process in small batches to save memory
MAX_QUERY_LENGTH = 5000  # Skip queries longer than this
MAX_JOINS = 8  # Skip queries with too many joins

# ============================================================================
# JSON ENCODER
# ============================================================================

class CustomJSONEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, (datetime, date, dt_time)):
            return obj.isoformat()
        elif isinstance(obj, timedelta):
            return str(obj)  # Convert timedelta to string format like "1 day, 2:30:00"
        elif isinstance(obj, Decimal):
            return float(obj)
        return super().default(obj)

# ============================================================================
# SQL FIXES
# ============================================================================

def fix_sql_for_duckdb(sql_text):
    if not sql_text:
        return sql_text
    sql_text = re.sub(r'\s+ON\s+UPDATE\s+CASCADE', '', sql_text, flags=re.IGNORECASE)
    sql_text = re.sub(r'\s+ON\s+DELETE\s+CASCADE', '', sql_text, flags=re.IGNORECASE)
    
    # Fix escaped quotes (\" to ")
    sql_text = sql_text.replace('\\"', '"')
    
    # Replace backticks with double quotes
    sql_text = sql_text.replace('`', '"')
    
    # Replace SAFE_DIVIDE with CASE statement for DuckDB
    # SAFE_DIVIDE(a, b) -> CASE WHEN b = 0 OR b IS NULL THEN NULL ELSE a / b END
    def replace_safe_divide(text):
        while True:
            match = re.search(r'SAFE_DIVIDE\s*\(', text, flags=re.IGNORECASE)
            if not match:
                break
            
            start = match.end()
            paren_depth = 1
            i = start
            
            # Find matching closing parenthesis
            while i < len(text) and paren_depth > 0:
                if text[i] == '(':
                    paren_depth += 1
                elif text[i] == ')':
                    paren_depth -= 1
                i += 1
            
            if paren_depth != 0:
                break  # Unbalanced parentheses
            
            args = text[start:i-1]
            
            # Find comma separating arguments (not inside nested parens)
            paren_depth = 0
            comma_pos = -1
            for j, char in enumerate(args):
                if char == '(':
                    paren_depth += 1
                elif char == ')':
                    paren_depth -= 1
                elif char == ',' and paren_depth == 0:
                    comma_pos = j
                    break
            
            if comma_pos == -1:
                break  # Can't find separator
            
            numerator = args[:comma_pos].strip()
            denominator = args[comma_pos+1:].strip()
            replacement = f'CASE WHEN {denominator} = 0 OR {denominator} IS NULL THEN NULL ELSE {numerator} / {denominator} END'
            
            text = text[:match.start()] + replacement + text[i:]
        
        return text
    
    sql_text = replace_safe_divide(sql_text)
    
    # Replace SAFE_CAST with TRY_CAST for DuckDB
    sql_text = re.sub(r'\bSAFE_CAST\s*\(', 'TRY_CAST(', sql_text, flags=re.IGNORECASE)
    
    # Replace SAFE_SUBTRACT with simple subtraction
    sql_text = re.sub(r'\bSAFE_SUBTRACT\s*\(\s*([^,]+?)\s*,\s*([^)]+?)\s*\)', r'(\1 - \2)', sql_text, flags=re.IGNORECASE)
    
    # Add quotes around table names with hyphens/dots that aren't already quoted
    # Pattern: matches table names like pacsun-09012025.mondaysmart_pacsun_ingestion_dev.mondaysmart_planned_subset_daily
    # that appear after FROM, JOIN, INTO, UPDATE, or TABLE keywords
    pattern = r'\b(FROM|JOIN|INTO|UPDATE|TABLE)\s+(?!")([a-zA-Z0-9_.-]+\.[a-zA-Z0-9_.-]+[a-zA-Z0-9_-]+)(?!")'
    sql_text = re.sub(pattern, r'\1 "\2"', sql_text, flags=re.IGNORECASE)
    
    return sql_text

def reorder_create_statements(schema):
    """Reorder CREATE TABLE statements to respect foreign key dependencies."""
    if not schema:
        return []
    
    statements = [s.strip() for s in re.split(r';(?=\s*CREATE|\s*$)', schema, flags=re.IGNORECASE) if s.strip()]
    table_deps = {}
    
    for stmt in statements:
        if not stmt.upper().startswith('CREATE'):
            continue
        
        match = re.search(r'CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?"([^"]+)"', stmt, re.IGNORECASE)
        if not match:
            continue
        
        table_name = match.group(1)
        refs = re.findall(r'REFERENCES\s+(\w+)', stmt, re.IGNORECASE)
        table_deps[table_name] = [ref.lower() for ref in refs]
    
    ordered = []
    processed = set()
    
    def add_table(name):
        if name in processed or name not in table_deps:
            return
        for dep in table_deps[name]:
            if dep != name:
                add_table(dep)
        processed.add(name)
        for stmt in statements:
            if re.search(rf'CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?"{re.escape(name)}"', stmt, re.IGNORECASE):
                ordered.append(stmt)
                break
    
    for table in table_deps:
        add_table(table)
    
    return ordered

# ============================================================================
# QUERY EXECUTION WITH TIMEOUT
# ============================================================================

def timeout_handler(signum, frame):
    raise TimeoutError("Query execution timeout")

def execute_entry_direct(entry):
    """Execute a single entry directly (for parallel processing)."""
    result = {
        'entry': entry,
        'status': 'ERROR',
        'reason': '',
        'execution_result': None
    }
    
    try:
        # Get data
        schema = entry.get('extra_info', {}).get('schema', '')
        inserts = entry.get('extra_info', {}).get('insert_statements', '')
        query = entry.get('reward_model', {}).get('ground_truth', '')
        
        if not schema or not query:
            result['reason'] = "Missing schema or query"
            return result
        
        # Fix SQL
        schema = fix_sql_for_duckdb(schema)
        inserts = fix_sql_for_duckdb(inserts)
        query = fix_sql_for_duckdb(query)
        
        # Set timeout alarm
        signal.signal(signal.SIGALRM, timeout_handler)
        signal.alarm(QUERY_TIMEOUT)
        
        # Execute directly
        conn = duckdb.connect(':memory:')
        cursor = conn.cursor()
        
        # Execute schema
        for stmt in reorder_create_statements(schema):
            if stmt.strip():
                cursor.execute(stmt)
        
        # Execute inserts
        if inserts:
            for insert_stmt in inserts.split(';'):
                insert_stmt = insert_stmt.strip()
                if insert_stmt and insert_stmt.upper().startswith('INSERT'):
                    cursor.execute(insert_stmt)
        
        # Execute query
        cursor.execute(query)
        results = cursor.fetchall()
        col_names = [desc[0] for desc in cursor.description] if cursor.description else []
        
        # Cancel alarm - query completed successfully
        signal.alarm(0)
        
        conn.close()
        
        # Format results
        if not results:
            result['execution_result'] = []
        elif len(results) == 1 and len(results[0]) == 1:
            result['execution_result'] = str(results[0][0])
        elif col_names:
            result['execution_result'] = [
                {col_names[i]: row[i] for i in range(len(col_names))}
                for row in results
            ]
        else:
            result['execution_result'] = [list(row) for row in results]
        
        result['status'] = 'SUCCESS'
        result['reason'] = 'Query executed successfully'
        
    except TimeoutError:
        signal.alarm(0)  # Cancel alarm
        result['reason'] = f"Query timeout after {QUERY_TIMEOUT}s"
    except Exception as e:
        signal.alarm(0)  # Cancel alarm
        result['reason'] = f"Execution error: {str(e)}"
    
    return result

# ============================================================================
# MAIN PROCESSING
# ============================================================================

def execute_entry_wrapper(entry):
    """Wrapper function for parallel processing."""
    return execute_entry_direct(entry)

def process_json_file(json_file_path, output_dir=None):
    """Process JSON file with parallel processing."""
    
    print(f"\n{'='*80}")
    print(f"Processing: {Path(json_file_path).name}")
    print(f"Using DuckDB with {QUERY_TIMEOUT}s timeout per query")
    print(f"Using {NUM_WORKERS} parallel workers")
    print(f"{'='*80}\n")
    
    # Load data
    with open(json_file_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    if not isinstance(data, list):
        data = [data]
    
    # Setup output
    if output_dir is None:
        output_dir = Path(json_file_path).parent
    else:
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
    
    print(f"Total entries: {len(data)}")
    print(f"Processing in batches of {BATCH_SIZE}...\n")
    
    start_time = time.time()
    success_entries = []
    error_entries = []
    
    # Process in batches to save memory
    total_batches = (len(data) + BATCH_SIZE - 1) // BATCH_SIZE
    
    with tqdm(total=len(data), desc="Processing") as pbar:
        for batch_idx in range(total_batches):
            start_idx = batch_idx * BATCH_SIZE
            end_idx = min(start_idx + BATCH_SIZE, len(data))
            batch = data[start_idx:end_idx]
            
            # Process batch in parallel
            with multiprocessing.Pool(processes=NUM_WORKERS) as pool:
                batch_results = pool.map(execute_entry_wrapper, batch)
            
            # Collect results
            for result in batch_results:
                if result['status'] == 'SUCCESS':
                    updated_entry = result['entry'].copy()
                    if 'extra_info' not in updated_entry:
                        updated_entry['extra_info'] = {}
                    updated_entry['extra_info']['execution_result'] = result['execution_result']
                    success_entries.append(updated_entry)
                else:
                    error_entries.append({
                        'entry': result['entry'],
                        'error_reason': result['reason']
                    })
                pbar.update(1)
    
    elapsed = time.time() - start_time
    
    # Save results
    print(f"\n{'='*80}")
    print(f"SUMMARY")
    print(f"{'='*80}")
    print(f"Total: {len(data)}")
    print(f"Success: {len(success_entries)} ({100*len(success_entries)/len(data):.1f}%)")
    print(f"Errors: {len(error_entries)} ({100*len(error_entries)/len(data):.1f}%)")
    print(f"Time: {elapsed/60:.1f} minutes")
    print(f"{'='*80}\n")
    
    if success_entries:
        success_path = output_dir / f"{Path(json_file_path).stem}_executed_success.json"
        with open(success_path, 'w', encoding='utf-8') as f:
            json.dump(success_entries, f, indent=2, ensure_ascii=False, cls=CustomJSONEncoder)
        print(f"✓ Success file: {success_path}")
    
    if error_entries:
        error_path = output_dir / f"{Path(json_file_path).stem}_executed_errors.json"
        with open(error_path, 'w', encoding='utf-8') as f:
            json.dump(error_entries, f, indent=2, ensure_ascii=False, cls=CustomJSONEncoder)
        print(f"✓ Error file: {error_path}")
    
    return success_entries, error_entries

# ============================================================================
# MAIN
# ============================================================================

if __name__ == "__main__":
    multiprocessing.set_start_method('spawn', force=True)
    
    try:
        process_json_file(INPUT_FILE, OUTPUT_DIR)
    except KeyboardInterrupt:
        print("\n\nInterrupted by user")
    except Exception as e:
        print(f"\nFatal error: {e}")
        import traceback
        traceback.print_exc()