import json
import sys
import re
from pathlib import Path
from multiprocessing import Pool
from tqdm import tqdm
import time

try:
    import duckdb
except ImportError:
    print("ERROR: DuckDB not installed. Installing now...")
    import subprocess
    subprocess.check_call([sys.executable, "-m", "pip", "install", "duckdb"])
    import duckdb

# ============================================================================
# CONFIGURATION
# ============================================================================
INPUT_FILE = "/Users/akhilpatha/Downloads/Data_Retail_LLM/Reports/Postgres_15k_verified_duckdb_success_only_duckdb_success_only_duckdb_success_only.json"
NUM_WORKERS = 12  # Can use more workers since it's in-memory!

# ============================================================================
# SQL COMPATIBILITY FIXES
# ============================================================================

def fix_sql_for_duckdb(sql_text):
    """Convert PostgreSQL SQL to DuckDB-compatible SQL."""
    if not sql_text:
        return sql_text
    
    # DuckDB is very PostgreSQL-compatible, so minimal changes needed
    # Just handle a few edge cases
    
    # Remove ON UPDATE/DELETE CASCADE (DuckDB handles differently)
    sql_text = re.sub(r'\s+ON\s+UPDATE\s+CASCADE', '', sql_text, flags=re.IGNORECASE)
    sql_text = re.sub(r'\s+ON\s+DELETE\s+CASCADE', '', sql_text, flags=re.IGNORECASE)
    
    return sql_text


def get_table_names_from_schema(schema):
    """Extract table names from CREATE TABLE statements."""
    pattern = r'CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?["]?(\w+)["]?'
    matches = re.findall(pattern, schema, re.IGNORECASE)
    return matches


def reorder_create_statements(schema):
    """Reorder CREATE TABLE statements to respect foreign key dependencies."""
    statements = []
    current_stmt = []
    
    for line in schema.split('\n'):
        current_stmt.append(line)
        if line.strip().endswith(');'):
            statements.append('\n'.join(current_stmt))
            current_stmt = []
    
    if current_stmt:
        statements.append('\n'.join(current_stmt))
    
    table_info = {}
    for stmt in statements:
        if not stmt.strip():
            continue
            
        table_match = re.search(r'CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?["]?(\w+)["]?', stmt, re.IGNORECASE)
        if not table_match:
            continue
        
        table_name = table_match.group(1)
        fk_pattern = r'REFERENCES\s+(\w+)\s*\('
        dependencies = set(re.findall(fk_pattern, stmt, re.IGNORECASE))
        
        table_info[table_name] = {
            'statement': stmt,
            'dependencies': dependencies
        }
    
    ordered_tables = []
    remaining = set(table_info.keys())
    
    while remaining:
        ready = [
            table for table in remaining
            if not (table_info[table]['dependencies'] & remaining)
        ]
        
        if not ready:
            ready = list(remaining)
        
        ordered_tables.extend(ready)
        remaining -= set(ready)
    
    return [table_info[table]['statement'] for table in ordered_tables if table in table_info]


# ============================================================================
# RESULT COMPARISON
# ============================================================================

def normalize_result(result):
    """Normalize query results for comparison."""
    if not result:
        return []
    
    if isinstance(result, list):
        if all(isinstance(row, dict) for row in result):
            return sorted([
                {k: (round(v, 6) if isinstance(v, float) else v) for k, v in row.items()}
                for row in result
            ], key=lambda x: str(sorted(x.items())))
        else:
            return sorted([
                tuple(round(v, 6) if isinstance(v, float) else v for v in row)
                for row in result
            ])
    
    return result


def compare_results(actual, expected):
    """Compare actual query results with expected results."""
    actual_norm = normalize_result(actual)
    expected_norm = normalize_result(expected)
    
    if actual_norm == expected_norm:
        return True, "Match"
    
    try:
        actual_set = {tuple(sorted(row.items())) if isinstance(row, dict) else tuple(row) if isinstance(row, (list, tuple)) else row for row in actual_norm}
        expected_set = {tuple(sorted(row.items())) if isinstance(row, dict) else tuple(row) if isinstance(row, (list, tuple)) else row for row in expected_norm}
        
        if actual_set == expected_set:
            return True, "Match (unordered)"
    except:
        pass
    
    actual_preview = str(actual_norm[:2]) if len(actual_norm) > 0 else "[]"
    expected_preview = str(expected_norm[:2]) if len(expected_norm) > 0 else "[]"
    return False, f"Expected: {expected_preview}, Got: {actual_preview}"


# ============================================================================
# QUERY EXECUTION
# ============================================================================

def execute_entry_duckdb(entry):
    """Execute a single entry using in-memory DuckDB database."""
    result = {
        "index": entry.get('extra_info', {}).get('index', 'N/A'),
        "db_id": entry.get('extra_info', {}).get('db_id', 'N/A'),
        "status": "UNKNOWN",
        "reason": None
    }
    
    # Create in-memory DuckDB database (super fast + PostgreSQL compatible!)
    conn = duckdb.connect(':memory:')
    
    try:
        schema = entry.get('extra_info', {}).get('schema', '')
        insert_statements = entry.get('extra_info', {}).get('insert_statements', '')
        query = entry.get('reward_model', {}).get('ground_truth', '')
        expected_result = entry.get('extra_info', {}).get('execution_result', [])
        
        if not query:
            result['status'] = "SKIPPED"
            result['reason'] = "No query"
            return result
        
        # Convert SQL to DuckDB-compatible format
        schema = fix_sql_for_duckdb(schema)
        insert_statements = fix_sql_for_duckdb(insert_statements)
        query = fix_sql_for_duckdb(query)
        
        # Create tables
        if schema:
            ordered_statements = reorder_create_statements(schema)
            
            for stmt in ordered_statements:
                if stmt.strip():
                    try:
                        conn.execute(stmt)
                    except Exception as e:
                        # Try without foreign key constraints if it fails
                        stmt_no_fk = re.sub(r',?\s*FOREIGN\s+KEY.*?\)', '', stmt, flags=re.IGNORECASE | re.DOTALL)
                        try:
                            conn.execute(stmt_no_fk)
                        except:
                            pass  # Skip if still fails
        
        # Insert data
        if insert_statements:
            for stmt in insert_statements.split(';'):
                stmt = stmt.strip()
                if stmt and stmt.upper().startswith('INSERT'):
                    try:
                        conn.execute(stmt)
                    except:
                        pass  # Skip failed inserts
        
        # Execute query
        result_obj = conn.execute(query)
        query_result = result_obj.fetchall()
        
        # Get column names from the result
        column_names = [desc[0] for desc in result_obj.description]
        
        # Convert to list of dictionaries to match expected format
        actual_result = [dict(zip(column_names, row)) for row in query_result]
        
        # Compare results
        is_match, message = compare_results(actual_result, expected_result)
        
        if is_match:
            result['status'] = "SUCCESS"
            result['reason'] = message
        else:
            result['status'] = "MISMATCH"
            result['reason'] = message
    
    except Exception as e:
        result['status'] = "ERROR"
        result['reason'] = str(e)[:200]
    
    finally:
        conn.close()
    
    return result


# ============================================================================
# MAIN PROCESSING
# ============================================================================

def process_json_file(json_file_path):
    """Process JSON file using in-memory DuckDB database (single-threaded)."""
    print(f"\n{'='*80}")
    print(f"Processing: {Path(json_file_path).name}")
    print(f"Using IN-MEMORY DuckDB (PostgreSQL-compatible + blazing fast!)")
    print(f"Single-threaded (DuckDB is so fast it doesn't need multiprocessing!)")
    print(f"{'='*80}\n")
    
    with open(json_file_path, 'r', encoding='utf-8') as f:
        loaded_data = json.load(f)
    
    # Handle nested structure with 'data' key
    if isinstance(loaded_data, dict) and 'data' in loaded_data:
        data = loaded_data['data']
    elif isinstance(loaded_data, list):
        data = loaded_data
    else:
        data = [loaded_data]
    
    print(f"Total entries: {len(data)}")
    print(f"Processing sequentially (still faster than PostgreSQL!)\n")
    
    # Process entries sequentially (DuckDB is fast enough!)
    results = []
    success_entries = []  # Store full original entries for successful queries
    success = error = mismatch = skipped = 0
    
    start_time = time.time()
    
    # Single-threaded processing with progress bar
    for entry in tqdm(data, desc="Processing queries", unit="query"):
        result = execute_entry_duckdb(entry)
        results.append(result)
        
        if result['status'] == "SUCCESS":
            success += 1
            success_entries.append(entry)  # Save the full original entry
        elif result['status'] == "MISMATCH":
            mismatch += 1
        elif result['status'] == "ERROR":
            error += 1
        else:
            skipped += 1
    
    elapsed_time = time.time() - start_time
    
    print(f"\n{'='*80}")
    print("SUMMARY")
    print(f"{'='*80}")
    print(f"Total: {len(data)}")
    print(f"Success: {success} ({success/len(data)*100:.1f}%)")
    print(f"Mismatch: {mismatch} ({mismatch/len(data)*100:.1f}%)")
    print(f"Errors: {error} ({error/len(data)*100:.1f}%)")
    print(f"Skipped: {skipped}")
    print(f"\nTime: {elapsed_time/60:.1f} minutes ({elapsed_time/len(data):.2f} sec/query)")
    print(f"Speed: {len(data)/elapsed_time:.1f} queries/second")
    print(f"{'='*80}\n")
    
    return results, success_entries


# ============================================================================
# MAIN
# ============================================================================

if __name__ == "__main__":
    if not Path(INPUT_FILE).exists():
        print(f"Error: File not found: {INPUT_FILE}")
        sys.exit(1)
    
    try:
        results, success_entries = process_json_file(INPUT_FILE)
        
        # Save complete results
        output_file = Path(INPUT_FILE).stem + "_duckdb_results.json"
        output_path = Path(INPUT_FILE).parent / output_file
        
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(results, f, indent=2, ensure_ascii=False)
        
        print(f"Complete results saved: {output_path}")
        
        # Save only successful entries with full original data
        if success_entries:
            success_file = Path(INPUT_FILE).stem + "_duckdb_success_only.json"
            success_path = Path(INPUT_FILE).parent / success_file
            
            with open(success_path, 'w', encoding='utf-8') as f:
                json.dump(success_entries, f, indent=2, ensure_ascii=False)
            
            print(f"Success-only results saved: {success_path} ({len(success_entries)} entries)")
        else:
            print("No successful entries to save.")
    
    except Exception as e:
        print(f"Fatal error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
