import subprocess
import sys
import os
import json
import re
import time
import warnings
from openai import OpenAI
from concurrent.futures import ThreadPoolExecutor, as_completed
import multiprocessing as mp
from tqdm import tqdm

# Helper to install packages inside the script
def install(package):
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", package])
    except:
        pass

# Install required libraries
try:
    import openai
except ImportError:
    print("📦 Installing required libraries (openai)...")
    install("openai")

from openai import OpenAI

warnings.filterwarnings("ignore")

# ==========================================
# 2. GLOBAL CONFIGURATION
# ==========================================

# --- RUN MODES ---
TEST_MODE = False  # Set to False to process the full file (WARNING: EXPENSIVE!)
TEST_ROWS = 15000 # Number of rows to process in TEST_MODE
START_ROW = 0   # inclusive (0-based index)
END_ROW = 6601 # exclusive

# --- INPUT/OUTPUT FILES ---
#FORMATTED_PROMPT_FILE = '/Users/akhilpatha/Downloads/Data_Retail_LLM/synthetic_gbq_training_data_unique_10000.json'
FORMATTED_PROMPT_FILE = '/Users/pratheekreddy/Downloads/Postgres_data_code/Data_creation/pacsun_dev_format.jsonl'
FINAL_OUTPUT_FILE = '/Users/pratheekreddy/Downloads/Postgres_data_code/Data_creation/pacsun_dev_insert.json'

# --- OPENAI SETTINGS ---
# Reads key securely from environment variable (Must be set manually on the server)
OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY") 
MODEL_NAME = "gpt-5.2"
# --- ORIGINAL SYSTEM PROMPT (User Request) ---
ORIGINAL_SYSTEM_PROMPT = """
You are an expert database assistant. You will be given a database schema,
a natural language question, and the correct SQL query to answer that question.

Your task is to:
1.  Generate a small set of plausible, synthetic INSERT statements (as a single string)
    that populate the tables in the schema.

2.  Determine what the execution result (e.g., a number, a string) of running the
    provided SQL query would be against your generated data.

You MUST respond with ONLY a valid JSON object containing two keys:
- "insert_statements": A single string containing all INSERT statements, separated by newlines.
- "execution_result": The single, final result (e.g., 3, "Mowgli", 100.5).
"""

# ==========================================
# 3. API CALLING LOGIC
# ==========================================

def get_generated_data_robust(client, schema, question, query):
    """Robust API call using the user-specified system prompt."""
    sys_prompt = ORIGINAL_SYSTEM_PROMPT
    
    # Safely format the user content as a single JSON string for strict parsing by GPT-4o
    user_content_dict = {
        "schema": f"```sql\n{schema.strip()}\n```",
        "question": question.strip(),
        "query": query.strip()
    }
    user_prompt = json.dumps(user_content_dict)
    
    try:
        resp = client.chat.completions.create(
            model=MODEL_NAME,
            messages=[{"role": "system", "content": sys_prompt}, {"role": "user", "content": user_prompt}],
            response_format={"type": "json_object"}
        )
        content = resp.choices[0].message.content
        if not content: raise ValueError("None content returned by API.")
        
        # Check if the output JSON contains the required keys
        data = json.loads(content)
        if "insert_statements" not in data or "execution_result" not in data: 
             raise ValueError("Missing required keys in GPT response.")
        return data
        
    except Exception as e:
        print(f"  [API Error]: {e}")
        if "rate limit" in str(e).lower(): time.sleep(5)
        return None

def run_augmentation():
    print("\n--- PHASE 4: Augmenting with OpenAI ---")
    
    if not os.path.exists(FORMATTED_PROMPT_FILE): 
        print(f"🛑 Error: Input file '{FORMATTED_PROMPT_FILE}' not found. Run data_sampler_filter.py first."); return
    
    if not OPENAI_API_KEY.startswith("sk-"): 
        print("🛑 Error: API Key not set correctly. Skipping API calls."); return

    client = OpenAI(api_key=OPENAI_API_KEY)
    
    # --- Load JSON array file ---
    data = []
    try:
        # with open(FORMATTED_PROMPT_FILE, 'r', encoding='utf-8') as f:
        #     data = json.load(f)

        data = []
        with open(FORMATTED_PROMPT_FILE, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                data.append(json.loads(line))

        
        print(f"✅ Successfully loaded {len(data)} records from JSON file.")
    except Exception as e:
        print(f"🛑 Error loading JSON file: {e}")
        return
    # ---------------------------------------------

    # --- Test Mode Implementation ---
    if TEST_MODE: 
        print(f"🔹 Processing rows from {START_ROW} to {END_ROW} (subset run)")
        data = data[START_ROW:END_ROW]
    else:
        print(f"🚀 FULL MODE: Processing all {len(data)} records. (WARNING: HIGH API COST)")
    # --------------------------------

    # Determine optimal number of workers
    max_workers = min(50, (mp.cpu_count() or 1) * 5)  # Cap at 50 to avoid rate limits
    
    print(f"Processing {len(data)} items with {max_workers} parallel workers...")
    
    def process_single_item(item_with_index):
        """Process a single item (used by parallel workers)"""
        i, item = item_with_index
        info = item.get('extra_info', {})
        current_index = info.get('index', i)
        
        # Ensure 'reward_model' and 'ground_truth' exist before proceeding
        sql_query = item.get('reward_model', {}).get('ground_truth', 'N/A')
        
        if sql_query == 'N/A':
            gen = None
        else:
            try:
                gen = get_generated_data_robust(
                    client, 
                    info.get('schema', ''), 
                    info.get('question', ''), 
                    sql_query
                )
            except Exception as e:
                gen = None
        
        # Append error placeholders or generated data
        info['insert_statements'] = gen['insert_statements'] if gen else "ERROR: FAILED_TO_GENERATE"
        info['execution_result'] = gen['execution_result'] if gen else "ERROR: FAILED_TO_GENERATE"
        item['extra_info'] = info
        return item
    
    # Use ThreadPoolExecutor for parallel processing
    final_data = [None] * len(data)  # Pre-allocate to maintain order
    
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        # Submit all tasks with their original indices
        future_to_index = {
            executor.submit(process_single_item, (i, item)): i 
            for i, item in enumerate(data)
        }
        
        # Process completed tasks with progress bar
        for future in tqdm(as_completed(future_to_index), total=len(data), desc="Processing"):
            try:
                original_index = future_to_index[future]
                result = future.result()
                final_data[original_index] = result
            except Exception as e:
                original_index = future_to_index[future]
                print(f"\n⚠️  Error processing index {original_index}: {e}")
                # Keep the original item with error markers
                final_data[original_index] = data[original_index]

    # Note: Writing the output as a standard JSON array now for simpler reading later
    with open(FINAL_OUTPUT_FILE, 'w', encoding='utf-8') as f: json.dump(final_data, f, indent=2)


    print(f"\n✅ Saved final augmented data: {FINAL_OUTPUT_FILE}")

# ==========================================
# MAIN EXECUTION
# ==========================================
if __name__ == "__main__":
    run_augmentation()
    print("\n🎉 API Augmentation Finished.") 
