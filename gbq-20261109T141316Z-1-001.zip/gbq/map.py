import json
import os
import re
from typing import Any, Dict, List


INPUT_FILE = "/Users/pratheekreddy/Downloads/Postgres_data_code/Data_creation/pad_with_schema.json"
OUTPUT_FILE = "/Users/pratheekreddy/Downloads/Postgres_data_code/Data_creation/pad_masked.json"


ORIGINAL_PROJECT_ID = "pacsun-09012025"
ORIGINAL_DATASET_ID = "mondaysmart_pacsun_ingestion_dev"
NEW_PROJECT_ID = "project_1"
NEW_DATASET_ID = "dataset_1"


def _replace_case_insensitive(text: str, needle: str, replacement: str) -> str:
    """Replace needle with replacement in text, case-insensitive."""
    return re.sub(re.escape(needle), replacement, text, flags=re.IGNORECASE)


def transform_record(record: Dict[str, Any]) -> Dict[str, Any]:
    """Transform a single record by masking sensitive identifiers."""
    out: Dict[str, Any] = dict(record)

    # Add original identifiers for traceability
    out["original_project_id"] = ORIGINAL_PROJECT_ID
    out["original_dataset_id"] = ORIGINAL_DATASET_ID
    
    # Add current (masked) identifiers
    out["current_project_id"] = NEW_PROJECT_ID
    out["current_dataset_id"] = NEW_DATASET_ID

    # Replace project/dataset in schema
    schema = out.get("schema")
    if isinstance(schema, str):
        schema = schema.replace(ORIGINAL_PROJECT_ID, NEW_PROJECT_ID)
        schema = schema.replace(ORIGINAL_DATASET_ID, NEW_DATASET_ID)
        out["schema"] = schema

    # Replace project/dataset in sql_query
    sql_query = out.get("sql_query")
    if isinstance(sql_query, str):
        sql_query = sql_query.replace(ORIGINAL_PROJECT_ID, NEW_PROJECT_ID)
        sql_query = sql_query.replace(ORIGINAL_DATASET_ID, NEW_DATASET_ID)
        # Also replace pacsun with sai in sql_query (case-insensitive)
        sql_query = _replace_case_insensitive(sql_query, "pacsun", "sai")
        out["sql_query"] = sql_query

    # Replace pacsun with sai in input_query (case-insensitive)
    question = out.get("input_query")
    if isinstance(question, str):
        out["input_query"] = _replace_case_insensitive(question, "pacsun", "sai")

    # Replace pacsun with sai in system_prompt (case-insensitive)
    system_prompt = out.get("system_prompt")
    if isinstance(system_prompt, str):
        out["system_prompt"] = _replace_case_insensitive(system_prompt, "pacsun", "sai")

    return out


def main() -> None:
    """Map sensitive client information to anonymized identifiers."""
    print(f"Reading input file: {INPUT_FILE}")
    with open(INPUT_FILE, "r", encoding="utf-8") as f:
        data = json.load(f)

    if not isinstance(data, list):
        raise ValueError("Expected input JSON to be a list of records")

    print(f"Processing {len(data)} records...")
    transformed: List[Any] = []
    for rec in data:
        if isinstance(rec, dict):
            transformed.append(transform_record(rec))
        else:
            transformed.append(rec)

    print(f"Writing output file: {OUTPUT_FILE}")
    with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
        json.dump(transformed, f, indent=2, ensure_ascii=False)
    
    print(f"✅ Successfully masked {len(transformed)} records")
    print(f"🎉 Masking complete! Output: {OUTPUT_FILE}")


if __name__ == "__main__":
    main()
