import json
import os
import re
import math
import numpy as np
import google.generativeai as genai
from openai import OpenAI
from tqdm import tqdm
from sklearn.metrics.pairwise import cosine_similarity
from concurrent.futures import ThreadPoolExecutor, as_completed
import multiprocessing as mp
from sklearn.cluster import MiniBatchKMeans


# --- Configuration ---
INPUT_FILE = "/Users/akhilpatha/Downloads/Data_Retail_LLM/Reports/Synthetic_GBQ_data_10k_Gemini-3_updated_verified.json"
OUTPUT_FILE = "/Users/akhilpatha/Downloads/Data_Retail_LLM/Reports/Synthetic_GBQ_data_10k_Gemini-3_updated_filtered.json"

# Keep OpenAI for the scoring/validation logic
MODEL_NAME = "gpt-5.2"
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "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")

# --- GOOGLE GEMINI CONFIGURATION ---
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "AIzaSyAyIH18Z0LAjkx0i9SNLUvVPiQhVjChQ_4")
GEMINI_EMBEDDING_MODEL = "models/text-embedding-004" 

SIMILARITY_THRESHOLD = 0.95 
EMBEDDING_MODEL = GEMINI_EMBEDDING_MODEL  

client = OpenAI(api_key=OPENAI_API_KEY)
genai.configure(api_key=GEMINI_API_KEY)

class DataProcessor:
    def __init__(self, input_file):
        try:
            with open(input_file, 'r') as f:
                self.data = json.load(f)
        except FileNotFoundError:
            print(f"❌ Error: Input file '{input_file}' not found.")
            self.data = []
            
        self.stats = {
            "total_input": len(self.data),
            "valid_passed": 0,
            "invalid_skipped": 0,
            "duplicates_removed": 0
        }
        
    # --- CORE LOGIC: SINGLE-PASS SCORING ---

    def _calculate_weighted_score(self, top_logprobs):
        """
        Calculates the weighted mean of probabilities for digit tokens.
        If the model says '8' with 60% prob and '9' with 40% prob, score is 8.4.
        """
        token_probs = {}
        
        for item in top_logprobs:
            token = item.token.strip()
            # Check if token is a digit 0-9
            if token.isdigit() and 0 <= int(token) <= 9:
                val = int(token)
                prob = math.exp(item.logprob)
                token_probs[val] = token_probs.get(val, 0.0) + prob

        if not token_probs:
            return 5.0 # Fallback if no digits found

        # Weighted Average Formula: Sum(Value * Prob) / Sum(Prob)
        total_prob = sum(token_probs.values())
        weighted_sum = sum(val * prob for val, prob in token_probs.items())
        
        return round(weighted_sum / total_prob, 4)

    def _analyze_entry(self, entry):
        """
        Worker function: Calls LLM to Validate AND Score in one go.
        """
        extra = entry.get('extra_info', {})
        
        # Extract schema from prompt content (it contains the DDL)
        prompt_list = entry.get('prompt', [])
        if prompt_list and len(prompt_list) > 0:
            prompt_content = prompt_list[0].get('content', '')
            # Extract just the schema DDL (before "Question:")
            if 'Question:' in prompt_content:
                schema = prompt_content.split('Question:')[0].strip()
            else:
                schema = prompt_content.strip()
        else:
            schema = extra.get('schema')  
        
        sql = entry.get('reward_model', {}).get('ground_truth')
        
        if not schema or not sql:
            return None, "Missing Data"

        # Prompt Strategy: Strict Text Format for easier LogProb extraction
        prompt = f"""
        You are a SQL Validator. Analyze the Query against the Schema.
        
        Task 1: Validity. Is the SQL syntactically and logically correct?
        Task 2: Score.For Valid data Rate quality (0-9) based on efficiency, correctness and style, 0 for invalid data.

        Schema: {schema}
        Query: {sql}

        Output Format (Strict):
        Reason: <Short 1 sentence reason>
        Valid: <Yes/No>
        Score: <Single Digit 0-9>
        """

        try:
            response = client.chat.completions.create(
                model=MODEL_NAME,
                messages=[{"role": "user", "content": prompt}],
                temperature=0,
                max_completion_tokens=100,  
                logprobs=True,      
                top_logprobs=5      
            )
            
            content = response.choices[0].message.content
            
            # DEBUG: Print first response to see format
            if not hasattr(self, '_debug_printed'):
                print(f"\n🔍 DEBUG - Sample LLM Response:\n{content}\n")

                self._debug_printed = True
            
            # 1. Parse Validity (Regex)
            valid_match = re.search(r"Valid:\s*(Yes|No|True|False)", content, re.IGNORECASE)
            is_valid = valid_match and valid_match.group(1).lower() in ['yes', 'true']
            
            if not is_valid:

                return None, f"Invalid SQL (Response: {content[:100]}...)"

            # We look at the very last token generated, which should be the score digit
            # Note: GPT tokenization might include newlines, so we check the last few tokens.
            
            logprobs_list = response.choices[0].logprobs.content
            final_score = 0.0 # Default
            
            # Walk backwards to find the digit token
            found_score = False
            for token_data in reversed(logprobs_list):
                txt = token_data.token.strip()
                if txt.isdigit():
                    # This is likely our score token. Calculate weighted average.
                    final_score = self._calculate_weighted_score(token_data.top_logprobs)
                    found_score = True
                    break
            
            # Fallback: parse text if logprob lookup failed
            if not found_score:
                score_match = re.search(r"Score:\s*(\d)", content)
                if score_match:
                    final_score = float(score_match.group(1))

            # Update Entry
            entry['sanity_passed'] = True
            entry['quality_score'] = final_score
            
            # Simplified Hardness classifier based on SQL keyword complexity
            sql_lower = sql.lower()
            complexity_score = 0
            
            # Count all SQL keywords/clauses (excluding basic SELECT/FROM)
            # Each keyword adds to complexity
            
            if " with " in sql_lower:
                complexity_score += 2
            if "recursive" in sql_lower:
                complexity_score += 3
            
            # Count subqueries (nested SELECTs)
            subquery_count = sql_lower.count("select") - 1
            complexity_score += min(subquery_count, 3)  # Cap at +3
            
            # Window functions (any use of OVER)
            if " over(" in sql_lower or " over (" in sql_lower:
                complexity_score += 3
            if "partition by" in sql_lower:
                complexity_score += 2
            
            # Advanced BigQuery-specific clauses
            if "qualify" in sql_lower:
                complexity_score += 3
            
            # Joins (any type)
            join_count = sql_lower.count("join")
            complexity_score += min(join_count, 3)  # Cap at +3
            
            # Grouping and filtering
            if "group by" in sql_lower:
                complexity_score += 1
            if "having" in sql_lower:
                complexity_score += 1
            if "where" in sql_lower:
                complexity_score += 0.5
            
            # Set operations
            if any(op in sql_lower for op in ["union", "intersect", "except"]):
                complexity_score += 2
            
            # Conditional logic
            if "case" in sql_lower:
                complexity_score += 1
            
            # Ordering and limiting
            if "order by" in sql_lower:
                complexity_score += 0.5
            if "limit" in sql_lower:
                complexity_score += 0.5
            
            # BigQuery-specific functions (general check)
            if "unnest" in sql_lower:
                complexity_score += 1
            if "array_" in sql_lower or "struct" in sql_lower:
                complexity_score += 1
            
            # Aggregation functions (general check - any aggregate adds complexity)
            agg_funcs = ["count(", "sum(", "avg(", "min(", "max(", "string_agg", 
                        "array_agg", "percentile", "stddev", "variance"]
            complexity_score += sum(1 for func in agg_funcs if func in sql_lower)
            
            # Round to integer
            complexity_score = int(complexity_score)
            
            # Classify based on complexity score
            if complexity_score >= 10:
                entry['hardness'] = "Expert"
            elif complexity_score >= 7:
                entry['hardness'] = "Advanced"
            elif complexity_score >= 4:
                entry['hardness'] = "Good"
            elif complexity_score >= 2:
                entry['hardness'] = "Simple"
            else:
                entry['hardness'] = "Poor"

            return entry, "Success"

        except Exception as e:
            return None, f"API Error: {str(e)}"

    def get_embeddings_batched(self, texts, batch_size=2000):
        """
        Fetches embeddings in batches to respect API limits.
        """
        embeddings = []
        print(f"Generating embeddings for {len(texts)} queries...")
        
        for i in range(0, len(texts), batch_size):
            batch = texts[i : i + batch_size]
            # Clean newlines for best embedding performance
            clean_batch = [t.replace("\n", " ") for t in batch]
            
            try:
                # Call Gemini Embedding API
                result = genai.embed_content(
                    model=GEMINI_EMBEDDING_MODEL,
                    content=clean_batch,
                    task_type="semantic_similarity"
                )
                batch_embeddings = result['embedding']
                embeddings.extend(batch_embeddings)
            except Exception as e:
                print(f"Embedding Error: {e}")
                return None
                
        # Return as float32 numpy array for memory efficiency
        return np.array(embeddings, dtype=np.float32)

    def run_pipeline(self, max_workers=None):
        """
        Runs the API step in parallel.
        """
        if max_workers is None:
            max_workers = min(100, (mp.cpu_count() or 1) * 10)
        
        print("--- Step 1: Sanity Check & Scoring ---")
        
        valid_data = []
        error_reasons = []
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            future_to_entry = {executor.submit(self._analyze_entry, entry): entry 
                             for entry in self.data}
            
            for future in tqdm(as_completed(future_to_entry), total=len(self.data)):
                res, status = future.result()
                if res:
                    valid_data.append(res)
                else:
                    self.stats['invalid_skipped'] += 1
                    error_reasons.append(status)

        self.data = valid_data
        self.stats['valid_passed'] = len(self.data)
        print(f"✅ Step 1 Complete. Valid Rows: {len(self.data)}")
        
        # Print error summary
        if error_reasons:
            from collections import Counter
            error_counts = Counter(error_reasons)
            print(f"\n⚠️  Errors encountered:")
            for error, count in error_counts.most_common():
                print(f"  - {error}: {count} occurrences")

    def deduplicate(self):
        print(f"--- Step 2: Cluster-Based Semantic Deduplication ---")
        if not self.data: return

        # --- 1. PREPARATION ---
        queries = [item['reward_model']['ground_truth'] for item in self.data]
        embeddings = self.get_embeddings_batched(queries)
        if embeddings is None: return

        num_rows = len(embeddings)
        print(f"Normalizing {num_rows} vectors...")
        
        # Normalize for Cosine Similarity (L2 Normalization)
        norm = np.linalg.norm(embeddings, axis=1, keepdims=True)
        embeddings = embeddings / (norm + 1e-10)

        remove_indices = set()

        # --- 2. CLUSTERING (Blocking) ---
        # Rule of thumb: sqrt(N/2) is often used, or ~100 items per cluster.
        n_clusters = 100
        print(f"Clustering into {n_clusters} groups to optimize comparison...")
        
        kmeans = MiniBatchKMeans(
            n_clusters=n_clusters, 
            random_state=42, 
            batch_size=1000,
            n_init='auto'
        )
        labels = kmeans.fit_predict(embeddings)
        centroids = kmeans.cluster_centers_
        
        # Create a map of Cluster ID -> [List of Data Indices]
        cluster_map = {}
        for idx, label in enumerate(labels):
            if label not in cluster_map: cluster_map[label] = []
            cluster_map[label].append(idx)

        # --- 3. INTRA-CLUSTER DEDUPLICATION ---
        print("Running Intra-Cluster comparisons...")
        for label, indices in tqdm(cluster_map.items(), desc="Intra-Cluster"):
            if len(indices) < 2: continue
            
            # Extract only the vectors for this cluster
            cluster_vectors = embeddings[indices] # Shape: (Cluster_Size, 1536)
            
            # Compute similarity matrix for just this cluster
            sim_matrix = np.dot(cluster_vectors, cluster_vectors.T)
            
            # Find duplicates
            rows, cols = np.where(sim_matrix > SIMILARITY_THRESHOLD)
            
            for r, c in zip(rows, cols):
                if c <= r: continue # Skip lower triangle & self-match
                
                idx_a = indices[r] # Map back to global index
                idx_b = indices[c]
                
                self._resolve_conflict(idx_a, idx_b, remove_indices)

        # --- 4. INTER-CLUSTER DEDUPLICATION (Boundary Check) ---
        # Compare clusters that are geometrically close to each other.
        print("Running Inter-Cluster (Neighbor) comparisons...")
        
        # Normalize centroids to find nearest clusters
        centroid_norms = np.linalg.norm(centroids, axis=1, keepdims=True)
        centroids_norm = centroids / (centroid_norms + 1e-10)
        
        # Compute similarity between CENTROIDS (500x500 matrix - extremely fast)
        centroid_sim = np.dot(centroids_norm, centroids_norm.T)
        
        # Threshold for "Neighboring Clusters"
        # If centroids are 90% similar, their contents might overlap.
        INTER_CLUSTER_THRESHOLD = 0.90
        
        cluster_pairs = np.where(centroid_sim > INTER_CLUSTER_THRESHOLD)
        checked_pairs = set()

        for c1, c2 in zip(cluster_pairs[0], cluster_pairs[1]):
            if c1 >= c2: continue # Skip duplicates and self
            if (c1, c2) in checked_pairs: continue
            checked_pairs.add((c1, c2))
            
            # Get indices for both clusters
            idxs_1 = cluster_map.get(c1, [])
            idxs_2 = cluster_map.get(c2, [])
            
            if not idxs_1 or not idxs_2: continue

            # Cross-Compare: Items in Cluster 1 vs Items in Cluster 2
            vecs_1 = embeddings[idxs_1]
            vecs_2 = embeddings[idxs_2]
            
            cross_sim = np.dot(vecs_1, vecs_2.T)
            
            # Find matches across the boundary
            rows, cols = np.where(cross_sim > SIMILARITY_THRESHOLD)
            
            for r, c in zip(rows, cols):
                global_idx_a = idxs_1[r]
                global_idx_b = idxs_2[c]
                
                self._resolve_conflict(global_idx_a, global_idx_b, remove_indices)

        # --- 5. FINALIZE ---
        self.data = [d for idx, d in enumerate(self.data) if idx not in remove_indices]
        self.stats['duplicates_removed'] = len(remove_indices)
        print(f"✅ Deduplication Done. Removed {len(remove_indices)} items.")

    def _resolve_conflict(self, idx_a, idx_b, remove_set):
        """
        Helper to safely add the lower-quality item to the removal set.
        """
        if idx_a in remove_set or idx_b in remove_set:
            return

        score_a = self.data[idx_a].get('quality_score', 0)
        score_b = self.data[idx_b].get('quality_score', 0)

        if score_a >= score_b:
            remove_set.add(idx_b)
        else:
            remove_set.add(idx_a)

    def save(self):
        output = {
            "metadata_stats": self.stats,
            "data": self.data
        }
        try:
            with open(OUTPUT_FILE, 'w') as f:
                json.dump(output, f, indent=2)
            print(f"💾 Saved to {OUTPUT_FILE}")
        except Exception as e:
            error_msg = f"Failed to save output file: {str(e)}"
            print(f"❌ Error: {error_msg}")

# --- EXECUTION ---
if __name__ == "__main__":
    if not OPENAI_API_KEY:
        print("OPENAI_API_KEY not found in environment variables.")
    else:
        # Initialize
        processor = DataProcessor(INPUT_FILE)
        
        # Run Combined Pipeline (Validity Score)
        processor.run_pipeline()
        
        # Run Local Deduplication
        processor.deduplicate()
        
        # Save
        processor.save()