import json
from google.cloud import bigquery
import re

def clean_sql(sql):
    """Remove markdown formatting and clean SQL"""
    sql = sql.replace('```sql', '').replace('```', '').strip()
    # Replace RECORD with STRUCT
    sql = re.sub(r'\bRECORD\b', 'STRUCT', sql, flags=re.IGNORECASE)
    # Replace FLOAT with FLOAT64 for BigQuery
    sql = re.sub(r'\bFLOAT\b', 'FLOAT64', sql, flags=re.IGNORECASE)
    # Remove all double quotes (we'll use backticks for table names)
    sql = sql.replace('"', '')
    return sql


def extract_create_statements(schema_text):
    """Extract individual CREATE TABLE statements from schema"""
    schema_clean = clean_sql(schema_text)
    
    # Find all CREATE TABLE positions
    create_pattern = r'CREATE\s+TABLE'
    matches = list(re.finditer(create_pattern, schema_clean, re.IGNORECASE))
    
    if not matches:
        return []
    
    statements = []
    for i, match in enumerate(matches):
        start = match.start()
        # Find the end: either the next CREATE TABLE or end of string
        if i + 1 < len(matches):
            end = matches[i + 1].start()
        else:
            end = len(schema_clean)
        
        # Extract the statement
        stmt = schema_clean[start:end].strip()
        
        # Remove trailing semicolon if present
        if stmt.endswith(';'):
            stmt = stmt[:-1].strip()
        
        statements.append(stmt)
    
    return statements

def extract_table_name(create_statement):
    """Extract table name from CREATE TABLE statement"""
    match = re.search(r'CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?[`"]?([\w\-\.]+)[`"]?\s*\(', 
                     create_statement, re.IGNORECASE)
    if match:
        full_name = match.group(1)
        # Get just the table name (last part after dots)
        return full_name.split('.')[-1]
    return None

def modify_create_statement(create_statement, target_project, target_dataset, table_name):
    """Modify CREATE TABLE statement with new project, dataset, and table name"""
    new_table_ref = f"`{target_project}.{target_dataset}.pd_{table_name}`"
    
    # Replace the table reference
    modified = re.sub(
        r'CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?[`"]?[\w\-\.]+[`"]?',
        f'CREATE TABLE {new_table_ref}',
        create_statement,
        count=1,
        flags=re.IGNORECASE
    )
    
    return modified, new_table_ref

def extract_insert_statements_for_table(insert_text, original_table_pattern):
    """Extract INSERT statements for a specific table"""
    insert_clean = clean_sql(insert_text)
    
    # Find all INSERT statements for this table
    # Match both quoted and unquoted table names
    pattern = rf'INSERT\s+INTO\s+[`"]?[^`"\s]*{re.escape(original_table_pattern)}[`"]?\s*\([^)]+\)\s*VALUES[^;]*;?'
    statements = re.findall(pattern, insert_clean, re.IGNORECASE | re.DOTALL)
    
    return statements

def modify_insert_statements(insert_statements, target_project, target_dataset, table_name):
    """Modify INSERT statements with new table reference"""
    new_table_ref = f"`{target_project}.{target_dataset}.pd_{table_name}`"
    
    modified_statements = []
    for stmt in insert_statements:
        modified = re.sub(
            r'INSERT\s+INTO\s+[`"]?[\w\-\.]+[`"]?',
            f'INSERT INTO {new_table_ref}',
            stmt,
            count=1,
            flags=re.IGNORECASE
        )
        modified_statements.append(modified)
    
    return modified_statements

def create_table_and_insert(client, create_sql, insert_sqls, table_ref):
    """Create table and insert data in BigQuery"""
    try:
        # Drop table if exists
        print(f"  Dropping existing table (if any): {table_ref}")
        client.query(f"DROP TABLE IF EXISTS {table_ref}").result()
        
        # Create table
        print(f"  Creating table: {table_ref}")
        client.query(create_sql).result()
        print(f"  ✅ Table created successfully")
        
        # Insert data
        if insert_sqls:
            print(f"  Inserting {len(insert_sqls)} INSERT statements...")
            inserted_count = 0
            for i, stmt in enumerate(insert_sqls, 1):
                if stmt.strip():
                    try:
                        client.query(stmt).result()
                        inserted_count += 1
                    except Exception as e:
                        print(f"    ⚠️  Error in INSERT statement {i}: {e}")
            
            # Get actual row count from BigQuery
            try:
                count_query = f"SELECT COUNT(*) as row_count FROM {table_ref}"
                count_result = client.query(count_query).result()
                row_count = list(count_result)[0].row_count
                print(f"  ✅ Successfully inserted {inserted_count}/{len(insert_sqls)} statements ({row_count} rows)")
            except Exception as e:
                print(f"  ✅ Successfully inserted {inserted_count}/{len(insert_sqls)} statements")
        
        return {"status": "SUCCESS", "table_ref": table_ref}
    
    except Exception as e:
        print(f"  ❌ Error: {e}")
        return {"status": "ERROR", "table_ref": table_ref, "error": str(e)}

def main():
    """Main execution"""
    # Configuration
    BILLING_PROJECT_ID = "ia-mlops-poc-data-scan-010824"
    TARGET_PROJECT_ID = "ia-mlops-poc"
    TARGET_DATASET_ID = "retail_llm"
    INPUT_FILE = "/Users/pratheekreddy/Downloads/Postgres_data_code/Data_creation/pad_insert_fixed.json"
    OUTPUT_FILE = "/Users/pratheekreddy/Downloads/Postgres_data_code/Data_creation/pad_insertfinal.json"
    GROUP_SIZE = 90
    TABLE_PREFIXES = ['pd1_', 'pd2_', 'pd3_', 'pd4_', 'pd5_', 'pd6_', 'pd7_', 'pd8_', 'pd9_', 'pd10_']
    
    print("="*70)
    print("BigQuery Table Creation from pacsun_dev_insert.json")
    print("="*70)
    
    # Load data
    print(f"\n📂 Loading data from: {INPUT_FILE}")
    with open(INPUT_FILE, 'r') as f:
        data = json.load(f)
    
    print(f"✅ Loaded {len(data)} samples")
    
    # Split data into groups of GROUP_SIZE
    total_samples = len(data)
    num_groups = (total_samples + GROUP_SIZE - 1) // GROUP_SIZE
    print(f"\n📊 Splitting {total_samples} samples into {num_groups} groups of {GROUP_SIZE} samples each")
    
    groups = []
    for i in range(num_groups):
        start_idx = i * GROUP_SIZE
        end_idx = min((i + 1) * GROUP_SIZE, total_samples)
        group_data = data[start_idx:end_idx]
        table_prefix = TABLE_PREFIXES[i] if i < len(TABLE_PREFIXES) else f'pd{i+1}_'
        groups.append({
            'data': group_data,
            'prefix': table_prefix,
            'start': start_idx,
            'end': end_idx
        })
        print(f"   • Group {i+1}: Samples {start_idx}-{end_idx-1} ({len(group_data)} samples) -> Prefix: {table_prefix}")
    
    # Initialize BigQuery client
    print(f"\n🔌 Connecting to BigQuery...")
    client = bigquery.Client(project=BILLING_PROJECT_ID)
    print(f"✅ Connected (billing project: {BILLING_PROJECT_ID})")
    print(f"   Target: {TARGET_PROJECT_ID}.{TARGET_DATASET_ID}")
    
    # Process each group
    all_results = []
    modified_data = []
    
    for group_idx, group in enumerate(groups):
        print(f"\n{'='*70}")
        print(f"PROCESSING GROUP {group_idx + 1}/{len(groups)}: {group['prefix']} (Samples {group['start']}-{group['end']-1})")
        print(f"{'='*70}")
        
        group_data = group['data']
        table_prefix = group['prefix']
        
        # Take first sample from this group to get schema and INSERT statements
        sample = group_data[0]
        schema_text = sample['extra_info']['schema']
        insert_text = sample['extra_info']['insert_statements']
        
        # Extract original table names from schema
        original_table_names = re.findall(r'CREATE TABLE `[^`]+\.([^`]+)`', schema_text)
        prefixed_table_names = [f"{table_prefix}{table}" for table in original_table_names]
        
        print(f"\n📋 Tables in this group: {', '.join(prefixed_table_names)}")
        
        # Modify INSERT statements to add table prefixes
        modified_insert_text = re.sub(
            r'INSERT INTO `([^`]+)\.([^`]+)`',
            lambda m: f'INSERT INTO `{m.group(1)}.{table_prefix}{m.group(2)}`',
            insert_text
        )
        
        # Extract CREATE TABLE statements
        create_statements = extract_create_statements(schema_text)
        print(f"✅ Found {len(create_statements)} CREATE TABLE statements")
        
        # Process each table in this group
        for i, create_stmt in enumerate(create_statements, 1):
            print(f"\n  Table {i}/{len(create_statements)}:")
            
            # Extract original table name from CREATE statement
            original_table_name = extract_table_name(create_stmt)
            if not original_table_name:
                print(f"  ⚠️  Could not extract table name, skipping...")
                continue
            
            prefixed_table_name = f"{table_prefix}{original_table_name}"
            print(f"  Original: {original_table_name}")
            print(f"  Prefixed: {prefixed_table_name}")
            
            # Create table reference with prefix
            new_table_ref = f"`{TARGET_PROJECT_ID}.{TARGET_DATASET_ID}.{prefixed_table_name}`"
            
            # Modify CREATE statement to use prefixed table name
            modified_create = re.sub(
                r'CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?[`"]?[\w\-\.]+[`"]?',
                f'CREATE TABLE {new_table_ref}',
                create_stmt,
                count=1,
                flags=re.IGNORECASE
            )
            
            # Extract INSERT statements for this table (now with prefix)
            pattern = rf'INSERT\s+INTO\s+[`"]?[^`"\s]*{re.escape(prefixed_table_name)}[`"]?\s*\([^)]+\)\s*VALUES[^;]*;?'
            insert_stmts = re.findall(pattern, modified_insert_text, re.IGNORECASE | re.DOTALL)
            print(f"  Found {len(insert_stmts)} INSERT statements")
            
            # Modify INSERT statements to use correct project/dataset
            modified_inserts = []
            for stmt in insert_stmts:
                modified = re.sub(
                    r'INSERT\s+INTO\s+[`"]?[\w\-\.]+[`"]?',
                    f'INSERT INTO {new_table_ref}',
                    stmt,
                    count=1,
                    flags=re.IGNORECASE
                )
                modified_inserts.append(modified)
            
            # Create table and insert data
            result = create_table_and_insert(client, modified_create, modified_inserts, new_table_ref)
            all_results.append({
                "group": table_prefix,
                "table_name": prefixed_table_name,
                "new_ref": new_table_ref,
                **result
            })
        
        # Add table_prefix and db_id to all samples in this group
        for item in group_data:
            info = item.get('extra_info', {})
            info['table_prefix'] = table_prefix
            info['db_id'] = prefixed_table_names
            info['insert_statements'] = modified_insert_text
            item['extra_info'] = info
            modified_data.append(item)
    
    # Save modified data with table_prefix and db_id
    print(f"\n💾 Saving modified data to: {OUTPUT_FILE}")
    with open(OUTPUT_FILE, 'w', encoding='utf-8') as f:
        json.dump(modified_data, f, indent=2)
    print(f"✅ Saved {len(modified_data)} samples to {OUTPUT_FILE}")
    
    # Summary
    print(f"\n{'='*70}")
    print("SUMMARY")
    print(f"{'='*70}")
    success_count = sum(1 for r in all_results if r['status'] == 'SUCCESS')
    fail_count = sum(1 for r in all_results if r['status'] == 'ERROR')
    
    print(f"Total tables processed: {len(all_results)}")
    print(f"✅ Successfully created: {success_count}")
    print(f"❌ Failed: {fail_count}")
    
    # Group summary
    print(f"\nTables by group:")
    for group in groups:
        prefix = group['prefix']
        group_results = [r for r in all_results if r['group'] == prefix]
        group_success = sum(1 for r in group_results if r['status'] == 'SUCCESS')
        print(f"  • {prefix}: {group_success}/{len(group_results)} tables created")
    
    if fail_count > 0:
        print(f"\nFailed tables:")
        for r in all_results:
            if r['status'] == 'ERROR':
                print(f"  - {r['table_name']}: {r.get('error', 'Unknown error')}")
    
    print(f"\n✅ All tables created with group prefixes in {TARGET_PROJECT_ID}.{TARGET_DATASET_ID}")
    print(f"✅ Modified data saved to: {OUTPUT_FILE}")
    print(f"{'='*70}")

if __name__ == "__main__":
    main()
