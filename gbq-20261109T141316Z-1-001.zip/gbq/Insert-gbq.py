import subprocess
import sys
import os
import json
import re
import time
import warnings
from openai import OpenAI
from concurrent.futures import ThreadPoolExecutor, as_completed
import multiprocessing as mp
from tqdm import tqdm

# Helper to install packages inside the script
def install(package):
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", package])
    except:
        pass

# Install required libraries
try:
    import openai
except ImportError:
    print("📦 Installing required libraries (openai)...")
    install("openai")

from openai import OpenAI

warnings.filterwarnings("ignore")

# ==========================================
# 2. GLOBAL CONFIGURATION
# ==========================================

# --- RUN MODES ---
TEST_MODE = False # Set to False to process the full file (WARNING: EXPENSIVE!)
#TEST_ROWS = 15000 # Number of rows to process in TEST_MODE
START_ROW = 0   # inclusive (0-based index)
END_ROW = 500 # exclusive

# --- GROUP CONFIGURATION ---
GROUP_SIZE = 90  # Number of samples per group - each group gets its own INSERT statements

# --- INPUT/OUTPUT FILES ---
#FORMATTED_PROMPT_FILE = '/Users/akhilpatha/Downloads/Data_Retail_LLM/synthetic_gbq_training_data_unique_10000.json'
FORMATTED_PROMPT_FILE = '/Users/pratheekreddy/Downloads/Postgres_data_code/Data_creation/pad_format.jsonl'
FINAL_OUTPUT_FILE = '/Users/pratheekreddy/Downloads/Postgres_data_code/Data_creation/pad_insert.json'

# --- OPENAI SETTINGS ---
# Reads key securely from environment variable (Must be set manually on the server)
OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY") 
MODEL_NAME = "gpt-5.2"
# --- SYSTEM PROMPTS ---
SCHEMA_INSERT_PROMPT = """
You are an expert BigQuery (GoogleSQL / Standard SQL) database assistant.

You will be given:
1. A database schema (contains set of CREATE TABLE statements)
2. A list of sample questions
3. A list of corresponding SQL queries for those questions
4. Additional context containing fiscal period definitions, date ranges, and time period abbreviations (ytd, mtd, wtd, etc.)

Your task:
Generate a comprehensive set of plausible synthetic INSERT statements to populate ALL tables in the schema with realistic data that will allow the SQL queries to return meaningful, non-null results.

**USE THE ADDITIONAL CONTEXT** (CRITICAL FOR REALISTIC DATA):
The additional_context field contains vital information you MUST use:
- Current fiscal year, month, week, and exact date context
- Time period abbreviations and their corresponding date ranges (ytd, mtd, qtd, wtd, lw, llw, trailing_13_weeks, etc.)
- Each time period's start_date, end_date, start fiscal week (start_fw), and end fiscal week (end_fw)
- Mandatory filters (channel_name values, dc_flag requirements)
- Entity hierarchies and KPI definitions
- **YOU MUST READ AND USE THIS CONTEXT** to generate INSERT data with:
  * Correct dates that fall within the time periods referenced in the questions
  * Correct channel_name values from the mandatory filters
  * Correct fiscal_year, fiscal_month, fiscal_week values matching the context
  * Realistic entity values (store IDs, product IDs) based on the hierarchy information

**PRIMARY GOAL**: 
- **CRITICAL**: When the provided SQL queries are executed against the INSERT data you generate, they MUST return NON-EMPTY execution results
- Every SQL query should produce actual rows with meaningful data - NOT empty results, NOT null results
- The INSERT data must satisfy ALL WHERE conditions, JOIN conditions, and filters in the SQL queries

IMPORTANT REQUIREMENTS:
- Analyze ALL the sample questions AND their corresponding SQL queries to understand what data is needed
- **CRITICAL**: Extract date ranges, time periods, and date filters from the SQL queries (WHERE date_id >= DATE('...'), week_id, fiscal_year, etc.)
- Generate INSERT statements with dates that MATCH the date filters in the queries
- If queries filter for 2026 dates, generate INSERT data with 2026 dates
- If queries filter for specific week_ids or fiscal periods, generate data for those exact periods
- Ensure data covers ALL the filters and conditions mentioned in the SQL queries (regions, categories, channels, stores, products, etc.)
- Make data diverse enough so queries return varied, realistic results (not all zeros or nulls)
- Generate sufficient rows (at least 10-20 rows per table) to ensure queries return meaningful results
- AVOID REPETITION: Each INSERT statement should add unique, different data - no duplicate rows
- Deduplicate: Don't insert the same values multiple times
- Make sure foreign key relationships are satisfied (if any)
- DO NOT use NULL values in INSERT statements - provide actual realistic values for all columns
- All columns must have meaningful non-null data that makes sense for the questions being asked

**CRITICAL COLUMN REQUIREMENTS** (MUST FOLLOW TO AVOID SYNTAX ERRORS):
- **STEP 1**: Count ALL columns in each CREATE TABLE statement BEFORE generating INSERT
- **STEP 2**: **MUST explicitly list ALL column names** in each INSERT statement: INSERT INTO `table` (col1, col2, col3, ...) VALUES (...)
- **STEP 3**: **MUST provide EXACT same number of values** as columns - if CREATE TABLE has 55 columns, INSERT must have exactly 55 values
- **DO NOT skip any columns** - every column in the schema must be included in the INSERT statement
- **Column order MUST match** the order in the CREATE TABLE statement exactly
- **DOUBLE-CHECK column count** - count columns in schema, count values in INSERT, they MUST be equal
- **Common error to avoid**: "Inserted row has wrong column count; Has 54, expected 55" - this means you miscounted!
- Example correct format:
  INSERT INTO `project.dataset.table` (column1, column2, column3) VALUES (value1, value2, value3);

**SYNTAX REQUIREMENTS** (MUST FOLLOW TO AVOID ERRORS):
- Use BACKTICKS for identifiers and fully-qualified table names:
  INSERT INTO `project.dataset.table` (col1, col2, ...) VALUES (...)
- Do NOT use PostgreSQL-style double quotes for identifiers
- Do NOT use PostgreSQL casts like ::DATE, ::TIMESTAMP, ::NUMERIC, ::JSONB
- For DATE/TIMESTAMP use BigQuery literals:
  DATE '2024-01-01'
  TIMESTAMP '2024-01-01 12:00:00+00'
- Strings must use single quotes: 'text'
- **IMPORTANT**: Each INSERT statement MUST end with a semicolon (;)
- **CRITICAL**: Use ONLY numeric literals (90.00, 100, 25.5) - NEVER use text words like "ninety", "hundred", etc.
- All numeric columns must have actual numbers, not text representations of numbers
- Avoid NULL values - use realistic data instead
- **NO SYNTAX ERRORS ALLOWED** - verify each INSERT statement is valid BigQuery SQL before including it

Output format:
Return ONLY a valid JSON object with exactly this key:
- "insert_statements": a single string with one or more BigQuery INSERT statements separated by newlines
"""

EXECUTION_RESULT_PROMPT = """
You are an expert BigQuery SQL query executor.

You will be given:
1. A database schema (CREATE TABLE statements)
2. INSERT statements that populate the tables
3. A SQL query to execute
4. A natural language question that the query answers

Your task:
Simulate executing the SQL query against the data from the INSERT statements and return the expected result.

IMPORTANT:
- Carefully analyze the INSERT statements to understand what data exists
- Execute the query logic mentally step-by-step
- Return the actual result rows that would be returned
- If the query would return no rows, return an empty array []
- If the query returns aggregate values (SUM, AVG, COUNT, etc.), calculate them based on the INSERT data
- Return realistic results based on the actual data in the INSERT statements

Output format:
Return ONLY a valid JSON object with exactly this key:
- "execution_result": an array of objects, where each object represents a row with column names as keys
  Example: [{"column1": value1, "column2": value2}, ...]
  If no rows match, return: []
"""

# ==========================================
# 3. API CALLING LOGIC
# ==========================================

def generate_insert_statements(client, schema, sample_questions, sample_queries, additional_context=""):
    """Generate INSERT statements for the schema with sample questions and queries (called once per group)."""
    user_content_dict = {
        "schema": f"```sql\n{schema.strip()}\n```",
        "sample_questions": sample_questions,  # Pass all questions from this group
        "sample_queries": sample_queries,  # Pass all SQL queries from this group
        "additional_context": additional_context  # Pass date/time period context
    }
    user_prompt = json.dumps(user_content_dict)
    
    try:
        resp = client.chat.completions.create(
            model=MODEL_NAME,
            messages=[{"role": "system", "content": SCHEMA_INSERT_PROMPT}, {"role": "user", "content": user_prompt}],
            response_format={"type": "json_object"}
        )
        content = resp.choices[0].message.content
        if not content: raise ValueError("None content returned by API.")
        
        data = json.loads(content)
        if "insert_statements" not in data: 
             raise ValueError("Missing insert_statements in GPT response.")
        return data["insert_statements"]
        
    except Exception as e:
        print(f"  [API Error generating INSERT statements]: {e}")
        if "rate limit" in str(e).lower(): time.sleep(5)
        return None


def generate_execution_result(client, schema, insert_statements, query, question):
    """Generate execution result for a single query using GPT."""
    user_content_dict = {
        "schema": f"```sql\n{schema.strip()}\n```",
        "insert_statements": insert_statements,
        "query": query,
        "question": question
    }
    user_prompt = json.dumps(user_content_dict)
    
    try:
        resp = client.chat.completions.create(
            model=MODEL_NAME,
            messages=[{"role": "system", "content": EXECUTION_RESULT_PROMPT}, {"role": "user", "content": user_prompt}],
            response_format={"type": "json_object"}
        )
        content = resp.choices[0].message.content
        if not content: 
            return []
        
        data = json.loads(content)
        return data.get("execution_result", [])
        
    except Exception as e:
        print(f"  [API Error generating execution result]: {e}")
        if "rate limit" in str(e).lower(): time.sleep(5)
        return []


def run_augmentation():
    print("\n--- BigQuery INSERT Statement Generation ---")
    
    if not os.path.exists(FORMATTED_PROMPT_FILE): 
        print(f"🛑 Error: Input file '{FORMATTED_PROMPT_FILE}' not found."); return
    
    if not OPENAI_API_KEY or not OPENAI_API_KEY.startswith("sk-"): 
        print("🛑 Error: API Key not set correctly. Skipping API calls."); return

    client = OpenAI(api_key=OPENAI_API_KEY)
    
    # --- Load JSONL file ---
    data = []
    try:
        with open(FORMATTED_PROMPT_FILE, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                data.append(json.loads(line))
        
        print(f"✅ Successfully loaded {len(data)} records from JSONL file.")
    except Exception as e:
        print(f"🛑 Error loading JSONL file: {e}")
        return

    if len(data) == 0:
        print("🛑 No data to process.")
        return

    # --- Apply Test Mode filtering ---
    if TEST_MODE: 
        print(f"� Processing rows from {START_ROW} to {END_ROW} (subset run)")
        data = data[START_ROW:END_ROW]
    else:
        print(f"🚀 FULL MODE: Processing all {len(data)} records. (WARNING: HIGH API COST)")
    
    # --- Split data into groups of 700 samples ---
    total_samples = len(data)
    num_groups = (total_samples + GROUP_SIZE - 1) // GROUP_SIZE  # Ceiling division
    print(f"\n� Splitting {total_samples} samples into {num_groups} groups of {GROUP_SIZE} samples each")
    
    groups = []
    for i in range(num_groups):
        start_idx = i * GROUP_SIZE
        end_idx = min((i + 1) * GROUP_SIZE, total_samples)
        group_data = data[start_idx:end_idx]
        groups.append({
            'data': group_data,
            'start': start_idx,
            'end': end_idx
        })
        print(f"  • Group {i+1}: Samples {start_idx}-{end_idx-1} ({len(group_data)} samples)")
    
    # --- Process each group separately ---
    all_final_data = []
    
    for group_idx, group in enumerate(groups):
        print(f"\n{'='*80}")
        print(f"PROCESSING GROUP {group_idx + 1}/{num_groups}: Samples {group['start']}-{group['end']-1}")
        print(f"{'='*80}")
        
        group_data = group['data']
        
        # --- STEP 1: Collect questions, queries, and additional context from this group ---
        print(f"\n📊 Step 1: Collecting questions, queries, and context from group {group_idx + 1}...")
        group_questions = []
        group_queries = []
        additional_context = ""
        
        for item in group_data:
            question = item.get('extra_info', {}).get('question', '')
            query = item.get('reward_model', {}).get('ground_truth', '')
            if question:
                group_questions.append(question)
            if query:
                group_queries.append(query)
            # Get additional_context from first item (same for all in group)
            if not additional_context:
                additional_context = item.get('extra_info', {}).get('additional_context', '')
        
        print(f"✅ Collected {len(group_questions)} questions and {len(group_queries)} queries")
        if additional_context:
            print(f"✅ Found additional context (date/time period definitions)")
        
        # --- STEP 2: Generate INSERT statements for this group ---
        print(f"\n📊 Step 2: Generating INSERT statements using {len(group_questions)} questions + {len(group_queries)} queries + schema + context...")
        schema = group_data[0].get('extra_info', {}).get('schema', '')
        if not schema:
            print("🛑 Error: No schema found in first record.")
            continue
        
        insert_statements = generate_insert_statements(client, schema, group_questions, group_queries, additional_context)
        if not insert_statements:
            print("🛑 Error: Failed to generate INSERT statements.")
            continue
        
        print(f"✅ Generated INSERT statements ({len(insert_statements)} chars)")
        
        # Count rows in each INSERT statement
        print(f"\n📊 Row counts per table (Group {group_idx + 1}):")
        insert_list = insert_statements.split("INSERT INTO")
        for i, stmt in enumerate(insert_list):
            if not stmt.strip():
                continue
            # Extract table name
            table_match = re.search(r'`[^`]+\.([^`]+)`', stmt)
            if table_match:
                table_name = table_match.group(1)
            else:
                table_name = f"Table_{i}"
            
            # Count rows by counting VALUE tuples
            values_match = re.search(r'VALUES\s*(.+)', stmt, re.IGNORECASE | re.DOTALL)
            if values_match:
                values_section = values_match.group(1)
                # Count opening parentheses at the start of each row
                row_count = len(re.findall(r'\n\s*\(', values_section)) + 1  # +1 for first row
                print(f"  • {table_name}: {row_count} rows")
            else:
                print(f"  • {table_name}: 0 rows")
        
        # --- STEP 3: Generate execution results for each record in this group ---
        print(f"\n📊 Step 3: Generating execution results for {len(group_data)} queries...")
        
        for item in tqdm(group_data, desc=f"Group {group_idx + 1} records"):
            info = item.get('extra_info', {})
            reward_model = item.get('reward_model', {})
            
            # Add INSERT statements (NO table_prefix, NO db_id)
            info['insert_statements'] = insert_statements
            
            # Generate execution result using GPT
            query = reward_model.get('ground_truth', '')
            question = info.get('question', '')
            
            if query and question:
                execution_result = generate_execution_result(client, schema, insert_statements, query, question)
                info['execution_result'] = execution_result
            else:
                info['execution_result'] = []
            
            item['extra_info'] = info
            all_final_data.append(item)
    
    # --- Save all groups to final output ---
    with open(FINAL_OUTPUT_FILE, 'w', encoding='utf-8') as f: 
        json.dump(all_final_data, f, indent=2)

    print(f"\n{'='*80}")
    print(f"✅ Saved final augmented data: {FINAL_OUTPUT_FILE}")
    print(f"📊 Total samples processed: {len(all_final_data)}")
    print(f"📊 Number of groups: {num_groups}")
    for i, group in enumerate(groups):
        print(f"  • Group {i+1}: {len(group['data'])} samples")

# ==========================================
# MAIN EXECUTION
# ==========================================
if __name__ == "__main__":
    run_augmentation()
    print("\n🎉 INSERT Statement Generation Finished.")