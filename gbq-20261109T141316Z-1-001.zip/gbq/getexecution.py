import json
import warnings
from google.cloud import bigquery
import re
from pathlib import Path
from tqdm import tqdm
import time
import sys
from multiprocessing import Pool
import copy
from collections import defaultdict
from datetime import date, datetime
from decimal import Decimal

# Suppress Google Cloud SDK authentication warnings
warnings.filterwarnings("ignore", message=".*Your application has authenticated using end user credentials.*")
warnings.filterwarnings("ignore", message=".*quota project.*")

class CustomJSONEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, (date, datetime)):
            return obj.isoformat()
        elif isinstance(obj, Decimal):
            return float(obj)
        else:
            return super().default(obj)

# =====================================================
# CONFIGURATION
# =====================================================

BILLING_PROJECT_ID = "ia-mlops-poc-data-scan-010824"
DATA_PROJECT_ID = "ia-mlops-poc"
DATASET_ID = "retail_llm"

INPUT_FILE = "/Users/pratheekreddy/Downloads/Postgres_data_code/Data_creation/pad_insertfinal.json"

NUM_WORKERS = 50

TEST_MODE = False
START_ROW = 0
END_ROW = 300

# =====================================================
# MODIFY QUERY
# =====================================================

def modify_query_for_bigquery(query, original_project, original_dataset, table_prefix):
    """
    Replace project_1.dataset_1.table_name
    with
    ia-mlops-poc.retail_llm.{table_prefix}table_name
    """
    pattern = rf'`?{re.escape(original_project)}\.{re.escape(original_dataset)}\.(\w+)`?'

    def replace_table(match):
        table_name = match.group(1)
        return f"`{DATA_PROJECT_ID}.{DATASET_ID}.{table_prefix}{table_name}`"

    modified_query = re.sub(pattern, replace_table, query)

    return modified_query


# =====================================================
# NORMALIZE RESULTS
# =====================================================

def normalize_result(result):

    if not result:
        return []

    normalized = []

    for row in result:

        new_row = {}

        for k, v in row.items():

            if isinstance(v, float):
                new_row[k] = round(v, 2)
            else:
                new_row[k] = v

        normalized.append(new_row)

    normalized.sort(key=lambda x: str(sorted(x.items())))

    return normalized


# =====================================================
# EXECUTE QUERY
# =====================================================

def execute_query(entry):

    client = bigquery.Client(project=BILLING_PROJECT_ID)

    result = {
        "index": entry.get("index"),
        "status": "UNKNOWN",
        "group": None,
        "gpt_match": None
    }

    updated_entry = copy.deepcopy(entry)

    try:

        query = entry["reward_model"]["ground_truth"]

        prefix = entry["extra_info"].get("table_prefix", "pd1_")

        result["group"] = prefix

        original_project = entry.get("current_project_id", "project_1")
        original_dataset = entry.get("current_dataset_id", "dataset_1")

        query_modified = modify_query_for_bigquery(
            query,
            original_project,
            original_dataset,
            prefix
        )

        query_job = client.query(query_modified)
        query_results = query_job.result()

        actual_result = [dict(row) for row in query_results]

        gpt_result = entry["extra_info"].get("execution_result")

        if gpt_result is not None:

            if normalize_result(gpt_result) == normalize_result(actual_result):
                result["gpt_match"] = True
            else:
                result["gpt_match"] = False

        updated_entry["extra_info"]["execution_result"] = actual_result

        result["status"] = "SUCCESS"

        return result, updated_entry

    except Exception as e:

        result["status"] = "ERROR"
        result["reason"] = str(e)

        return result, None


# =====================================================
# MAIN PROCESSING
# =====================================================

def process_json_file():

    print("\n==============================")
    print("Executing BigQuery Queries")
    print("==============================\n")

    with open(INPUT_FILE) as f:
        data = json.load(f)

    if TEST_MODE:
        data = data[START_ROW:END_ROW]

    print("Total queries:", len(data))

    results = []
    updated_entries = []

    group_stats = defaultdict(lambda: {
        "success": 0,
        "error": 0,
        "match": 0,
        "mismatch": 0
    })

    total_success = 0
    total_error = 0
    total_match = 0
    total_mismatch = 0

    start_time = time.time()

    with Pool(NUM_WORKERS) as pool:

        with tqdm(total=len(data), desc="Executing queries") as pbar:

            for result, updated_entry in pool.imap(execute_query, data):

                results.append(result)

                group = result["group"]

                if result["status"] == "SUCCESS":

                    total_success += 1
                    group_stats[group]["success"] += 1

                    if result["gpt_match"] is True:
                        total_match += 1
                        group_stats[group]["match"] += 1

                    elif result["gpt_match"] is False:
                        total_mismatch += 1
                        group_stats[group]["mismatch"] += 1

                    if updated_entry:
                        updated_entries.append(updated_entry)

                else:

                    total_error += 1
                    group_stats[group]["error"] += 1

                pbar.update(1)

    elapsed = time.time() - start_time

    # =====================================================
    # GROUP SUMMARY
    # =====================================================

    print("\n==============================")
    print("GROUP SUMMARY")
    print("==============================")

    for g in sorted(group_stats.keys()):

        s = group_stats[g]

        print(f"\nGroup {g}")

        print("Success :", s["success"])
        print("Errors  :", s["error"])
        print("Match   :", s["match"])
        print("Mismatch:", s["mismatch"])

    # =====================================================
    # FINAL TOTAL
    # =====================================================

    print("\n==============================")
    print("FINAL TOTAL")
    print("==============================")

    print("Total Queries :", len(data))
    print("Total Success :", total_success)
    print("Total Errors  :", total_error)

    print("\nGPT Comparison")

    print("Matches   :", total_match)
    print("Mismatches:", total_mismatch)

    print("\nExecution Time:", round(elapsed/60,2), "minutes")

    # =====================================================
    # SAVE UPDATED DATASET
    # =====================================================

    output_file = Path(INPUT_FILE).stem + "_with_execution.json"
    output_path = Path(INPUT_FILE).parent / output_file

    with open(output_path, "w") as f:
        json.dump(updated_entries, f, indent=2, cls=CustomJSONEncoder)

    print("\nSaved updated dataset →", output_path)


# =====================================================
# RUN
# =====================================================

if __name__ == "__main__":
    process_json_file()